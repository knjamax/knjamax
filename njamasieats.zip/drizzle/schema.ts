import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, bigint, decimal, json } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Categories for food items
 */
export const categories = mysqlTable("categories", {
  id: int("id").autoincrement().primaryKey(),
  nameEn: varchar("nameEn", { length: 100 }).notNull(),
  nameSw: varchar("nameSw", { length: 100 }).notNull(),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Category = typeof categories.$inferSelect;
export type InsertCategory = typeof categories.$inferInsert;

/**
 * Restaurants table
 */
export const restaurants = mysqlTable("restaurants", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 200 }).notNull(),
  description: text("description"),
  address: varchar("address", { length: 300 }),
  phone: varchar("phone", { length: 20 }),
  logoUrl: varchar("logoUrl", { length: 500 }),
  coverImageUrl: varchar("coverImageUrl", { length: 500 }),
  isOpen: boolean("isOpen").default(true).notNull(),
  deliveryFee: int("deliveryFee").default(0).notNull(),
  rating: decimal("rating", { precision: 3, scale: 1 }).default("4.0"),
  ownerId: int("ownerId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Restaurant = typeof restaurants.$inferSelect;
export type InsertRestaurant = typeof restaurants.$inferInsert;

/**
 * Menu items table
 */
export const menuItems = mysqlTable("menuItems", {
  id: int("id").autoincrement().primaryKey(),
  restaurantId: int("restaurantId").notNull(),
  nameEn: varchar("nameEn", { length: 200 }).notNull(),
  nameSw: varchar("nameSw", { length: 200 }).notNull(),
  description: text("description"),
  descriptionSw: text("descriptionSw"),
  price: int("price").notNull(),
  category: varchar("category", { length: 100 }),
  imageUrl: varchar("imageUrl", { length: 500 }),
  isAvailable: boolean("isAvailable").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type MenuItem = typeof menuItems.$inferSelect;
export type InsertMenuItem = typeof menuItems.$inferInsert;

/**
 * Orders table
 */
export const orders = mysqlTable("orders", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  restaurantId: int("restaurantId").notNull(),
  status: mysqlEnum("status", ["pending", "confirmed", "preparing", "ready", "picked_up", "delivering", "delivered", "cancelled"]).default("pending").notNull(),
  deliveryMethod: mysqlEnum("deliveryMethod", ["self_pickup", "restaurant_delivery", "independent_rider"]).notNull(),
  paymentMethod: mysqlEnum("paymentMethod", ["mpesa", "airtel_money", "cash_on_delivery"]).notNull(),
  paymentStatus: mysqlEnum("paymentStatus", ["pending", "paid", "failed"]).default("pending").notNull(),
  totalAmount: int("totalAmount").notNull(),
  deliveryFee: int("deliveryFee").default(0).notNull(),
  customerName: varchar("customerName", { length: 200 }),
  customerPhone: varchar("customerPhone", { length: 20 }),
  deliveryAddress: text("deliveryAddress"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Order = typeof orders.$inferSelect;
export type InsertOrder = typeof orders.$inferInsert;

/**
 * Order items table
 */
export const orderItems = mysqlTable("orderItems", {
  id: int("id").autoincrement().primaryKey(),
  orderId: int("orderId").notNull(),
  menuItemId: int("menuItemId").notNull(),
  itemNameEn: varchar("itemNameEn", { length: 200 }).notNull(),
  itemNameSw: varchar("itemNameSw", { length: 200 }).notNull(),
  quantity: int("quantity").notNull(),
  unitPrice: int("unitPrice").notNull(),
  totalPrice: int("totalPrice").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/**
 * Restaurant owner registration requests
 */
export const restaurantOwners = mysqlTable("restaurantOwners", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  ownerName: varchar("ownerName", { length: 200 }).notNull(),
  ownerEmail: varchar("ownerEmail", { length: 320 }).notNull(),
  ownerPhone: varchar("ownerPhone", { length: 20 }).notNull(),
  restaurantName: varchar("restaurantName", { length: 200 }).notNull(),
  restaurantAddress: text("restaurantAddress").notNull(),
  restaurantPhone: varchar("restaurantPhone", { length: 20 }),
  restaurantDescription: text("restaurantDescription"),
  cuisineType: varchar("cuisineType", { length: 100 }),
  deliveryMethod: varchar("deliveryMethod", { length: 50 }).default("self_pickup"),
  status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type RestaurantOwner = typeof restaurantOwners.$inferSelect;
export type InsertRestaurantOwner = typeof restaurantOwners.$inferInsert;

export type OrderItem = typeof orderItems.$inferSelect;
export type InsertOrderItem = typeof orderItems.$inferInsert;
