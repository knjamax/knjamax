CREATE TABLE `restaurantOwners` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`ownerName` varchar(200) NOT NULL,
	`ownerEmail` varchar(320) NOT NULL,
	`ownerPhone` varchar(20) NOT NULL,
	`restaurantName` varchar(200) NOT NULL,
	`restaurantAddress` text NOT NULL,
	`restaurantPhone` varchar(20),
	`restaurantDescription` text,
	`cuisineType` varchar(100),
	`deliveryMethod` varchar(50) DEFAULT 'self_pickup',
	`status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `restaurantOwners_id` PRIMARY KEY(`id`)
);
