import { useLanguage } from "@/contexts/LanguageContext";
import { useCart } from "@/contexts/CartContext";
import Navigation from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Minus, Plus, Trash2, ShoppingBag, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";

export default function Cart() {
  const { t, language } = useLanguage();
  const { items, updateQuantity, removeFromCart, getSubtotal, clearCart, getItemCount } = useCart();

  const formatTzs = (amount: number) =>
    new Intl.NumberFormat("sw-TZ", { style: "currency", currency: "TZS", minimumFractionDigits: 0 }).format(amount);

  const subtotal = getSubtotal();

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />

      <main className="flex-1 py-8">
        <div className="container max-w-2xl">
          <Link href="/restaurants">
            <Button variant="ghost" size="sm" className="mb-6 text-muted-foreground">
              <ArrowLeft className="h-4 w-4 mr-1" /> {t("common.back")}
            </Button>
          </Link>

          <h1 className="font-display text-3xl font-bold text-foreground mb-8">
            {t("cart.title")}
            {getItemCount() > 0 && (
              <span className="text-lg font-normal text-muted-foreground ml-2">
                ({getItemCount()} {t("tracking.items").toLowerCase()})
              </span>
            )}
          </h1>

          {items.length === 0 ? (
            <div className="text-center py-20">
              <ShoppingBag className="h-16 w-16 mx-auto text-muted-foreground/30 mb-4" />
              <p className="text-muted-foreground text-lg mb-6">{t("cart.empty")}</p>
              <Link href="/restaurants">
                <Button>{t("cart.browseRestaurants")}</Button>
              </Link>
            </div>
          ) : (
            <div>
              {/* Cart Items */}
              <div className="space-y-3 mb-6">
                {items.map((item, i) => (
                  <motion.div
                    key={item.menuItemId}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.05 }}
                    className="flex items-center gap-4 p-4 bg-white rounded-xl border border-border/50"
                  >
                    <div className="flex-1 min-w-0">
                      <h3 className="font-medium text-foreground truncate">
                        {language === "sw" ? item.itemNameSw : item.itemNameEn}
                      </h3>
                      <p className="text-sm text-primary font-semibold">
                        {formatTzs(item.price)}
                      </p>
                    </div>
                    <div className="flex items-center gap-1">
                      <Button variant="outline" size="icon" className="h-7 w-7" onClick={() => updateQuantity(item.menuItemId, item.quantity - 1)}>
                        <Minus className="h-3 w-3" />
                      </Button>
                      <span className="w-8 text-center text-sm font-semibold">{item.quantity}</span>
                      <Button variant="outline" size="icon" className="h-7 w-7" onClick={() => updateQuantity(item.menuItemId, item.quantity + 1)}>
                        <Plus className="h-3 w-3" />
                      </Button>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="font-semibold text-foreground">{formatTzs(item.price * item.quantity)}</p>
                      <Button variant="ghost" size="icon" className="h-6 w-6 text-muted-foreground" onClick={() => removeFromCart(item.menuItemId)}>
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </motion.div>
                ))}
              </div>

              <Separator className="mb-6" />

              {/* Order Summary */}
              <div className="bg-white rounded-xl border border-border/50 p-6 space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">{t("cart.subtotal")}</span>
                  <span className="font-medium">{formatTzs(subtotal)}</span>
                </div>
                <div className="flex justify-between text-lg font-bold pt-2 border-t border-border/50">
                  <span>{t("cart.total")}</span>
                  <span className="text-primary">{formatTzs(subtotal)}</span>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-between mt-6 gap-4">
                <Button variant="outline" onClick={clearCart}>
                  {t("cart.clearCart")}
                </Button>
                <Link href="/checkout">
                  <Button size="lg" className="px-8 gap-2 shadow-lg shadow-primary/20">
                    {t("cart.checkout")}
                  </Button>
                </Link>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
