import { useLanguage } from "@/contexts/LanguageContext";
import { useCart } from "@/contexts/CartContext";
import Navigation from "@/components/Navigation";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Minus, Plus, ShoppingCart, ArrowLeft } from "lucide-react";
import { Link, useRoute } from "wouter";
import { useState, useMemo } from "react";
import { toast } from "sonner";
import { motion } from "framer-motion";

interface QuantityMap {
  [key: number]: number;
}

export default function RestaurantMenu() {
  const { t, language } = useLanguage();
  const { addToCart, getItemCount, updateQuantity: cartUpdateQuantity } = useCart();
  const [, params] = useRoute("/restaurants/:id");
  const restaurantId = parseInt(params?.id || "0");
  const [quantities, setQuantities] = useState<QuantityMap>({});

  const { data: restaurant } = trpc.restaurants.getById.useQuery({ id: restaurantId });
  const { data: menuItems, isLoading } = trpc.menuItems.getByRestaurant.useQuery({ restaurantId });

  const formatTzs = (amount: number) =>
    new Intl.NumberFormat("sw-TZ", { style: "currency", currency: "TZS", minimumFractionDigits: 0 }).format(amount);

  const categories = useMemo(() => {
    if (!menuItems) return [];
    const cats = new Set(menuItems.map(i => i.category).filter(Boolean));
    return Array.from(cats);
  }, [menuItems]);

  const handleAddToCart = (item: { id: number; nameEn: string; nameSw: string; price: number }) => {
    if (!restaurant) return;
    const qty = quantities[item.id] || 1;
    addToCart({
      menuItemId: item.id,
      restaurantId: restaurant.id,
      itemNameEn: item.nameEn,
      itemNameSw: item.nameSw,
      price: item.price,
    });
    if (qty > 1) {
      setQuantities(prev => ({ ...prev, [item.id]: 1 }));
      cartUpdateQuantity(item.id, qty);
    }
    const itemName = language === "sw" && item.nameSw ? item.nameSw : item.nameEn;
    toast.success(`${itemName} x${qty} ${t("cart.items")}`);
  };

  const handleQuantityChange = (id: number, delta: number) => {
    setQuantities(prev => {
      const current = prev[id] || 1;
      const newQty = Math.max(1, current + delta);
      return { ...prev, [id]: newQty };
    });
  };

  if (!restaurant) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navigation />
        <div className="flex-1 flex items-center justify-center">
          <p className="text-muted-foreground">{t("common.loading")}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />

      {/* Restaurant Header */}
      <section className="relative">
        <div className="h-48 md:h-64 bg-gradient-to-br from-primary/20 to-accent/10 relative overflow-hidden">
          {restaurant.coverImageUrl && (
            <img src={restaurant.coverImageUrl} alt={restaurant.name} className="w-full h-full object-cover" />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" />
        </div>
        <div className="container -mt-16 relative z-10">
          <Link href="/restaurants">
            <Button variant="ghost" size="sm" className="mb-4 text-muted-foreground">
              <ArrowLeft className="h-4 w-4 mr-1" /> {t("common.back")}
            </Button>
          </Link>
          <div className="flex items-end gap-4">
            <div className="w-20 h-20 rounded-2xl bg-white shadow-lg border border-border/50 flex items-center justify-center text-3xl font-display font-bold text-primary">
              {restaurant.logoUrl ? (
                <img src={restaurant.logoUrl} alt={restaurant.name} className="w-full h-full rounded-2xl object-cover" />
              ) : restaurant.name.charAt(0)}
            </div>
            <div className="pb-2">
              <h1 className="font-display text-2xl md:text-3xl font-bold text-foreground">{restaurant.name}</h1>
              <div className="flex items-center gap-3 text-sm text-muted-foreground mt-1">
                <Badge variant={restaurant.isOpen ? "default" : "secondary"}>
                  {restaurant.isOpen ? t("restaurants.open") : t("restaurants.closed")}
                </Badge>
                {restaurant.address && (
                  <span className="flex items-center gap-1">{restaurant.address}</span>
                )}
                {restaurant.deliveryFee > 0 && (
                  <span>{t("restaurants.delivery")}: {formatTzs(restaurant.deliveryFee)}</span>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Category Tabs */}
      {categories.length > 0 && (
        <div className="container mt-6">
          <div className="flex gap-2 overflow-x-auto pb-2">
            {categories.map(cat => (
              <Badge key={cat} variant="outline" className="px-4 py-1.5 text-sm shrink-0 cursor-default">
                {cat}
              </Badge>
            ))}
          </div>
        </div>
      )}

      <Separator className="mt-6" />

      {/* Menu Items */}
      <section className="py-8 flex-1">
        <div className="container">
          {isLoading ? (
            <div className="grid gap-4">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="h-24 rounded-xl bg-muted animate-pulse" />
              ))}
            </div>
          ) : !menuItems || menuItems.length === 0 ? (
            <div className="text-center py-20">
              <p className="text-muted-foreground">{t("restaurants.noResults")}</p>
            </div>
          ) : (
            <div className="grid gap-4 max-w-3xl">
              {menuItems.map((item, i) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.03 }}
                  className="group"
                >
                  <div className={`flex items-start gap-4 p-4 rounded-xl border transition-all duration-200
                    ${!item.isAvailable ? "bg-muted/50 opacity-60" : "bg-white border-border/50 hover:border-primary/20 hover:shadow-md"}`}>
                    {/* Image or Placeholder */}
                    <div className="w-16 h-16 rounded-lg bg-gradient-to-br from-primary/10 to-accent/10 shrink-0 flex items-center justify-center overflow-hidden">
                      {item.imageUrl ? (
                        <img src={item.imageUrl} alt={item.nameEn} className="w-full h-full object-cover" />
                      ) : (
                        <span className="text-lg">🍽️</span>
                      )}
                    </div>

                    {/* Details */}
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-foreground truncate">
                        {language === "sw" && item.nameSw ? item.nameSw : item.nameEn}
                      </h3>
                      <p className="text-sm text-muted-foreground mt-0.5 line-clamp-2">
                        {language === "sw" && item.descriptionSw ? item.descriptionSw : item.description}
                      </p>
                      <div className="flex items-center justify-between mt-2">
                        <span className="font-semibold text-primary">{formatTzs(item.price)}</span>
                        {item.category && (
                          <Badge variant="secondary" className="text-xs">{item.category}</Badge>
                        )}
                      </div>
                    </div>

                    {/* Actions */}
                    {item.isAvailable && restaurant.isOpen && (
                      <div className="flex flex-col items-center gap-1 shrink-0">
                        <div className="flex items-center gap-1">
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-7 w-7"
                            onClick={() => handleQuantityChange(item.id, -1)}
                          >
                            <Minus className="h-3 w-3" />
                          </Button>
                          <span className="w-8 text-center text-sm font-semibold">
                            {quantities[item.id] || 1}
                          </span>
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-7 w-7"
                            onClick={() => handleQuantityChange(item.id, 1)}
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                        </div>
                        <Button
                          size="sm"
                          className="h-8 text-xs gap-1 mt-1"
                          onClick={() => handleAddToCart(item as any)}
                        >
                          <ShoppingCart className="h-3 w-3" />
                          {t("menu.addToCart")}
                        </Button>
                      </div>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Floating Cart Button */}
      {getItemCount() > 0 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40">
          <Link href="/cart">
            <Button size="lg" className="shadow-2xl shadow-primary/30 gap-2 px-6">
              <ShoppingCart className="h-5 w-5" />
              {t("nav.cart")} ({getItemCount()})
            </Button>
          </Link>
        </div>
      )}
    </div>
  );
}
