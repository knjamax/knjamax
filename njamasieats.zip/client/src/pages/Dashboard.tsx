import { useLanguage } from "@/contexts/LanguageContext";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import {
  Store, ShoppingCart, LayoutDashboard, Plus, Pencil, Trash2, Package, ChefHat,
  Clock, CheckCircle, XCircle, Truck, MapPin, Bike, Users, FileCheck, FileX
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { motion } from "framer-motion";

const statusLabels: Record<string, { en: string; sw: string }> = {
  pending: { en: "Pending", sw: "Inasubiri" },
  confirmed: { en: "Confirmed", sw: "Imethibitishwa" },
  preparing: { en: "Preparing", sw: "Inatayarishwa" },
  ready: { en: "Ready", sw: "Imeandaliwa" },
  picked_up: { en: "Picked Up", sw: "Imechukuliwa" },
  delivering: { en: "Delivering", sw: "Inasafirishwa" },
  delivered: { en: "Delivered", sw: "Imefika" },
  cancelled: { en: "Cancelled", sw: "Imeghairiwa" },
};

const statusColors: Record<string, string> = {
  pending: "bg-yellow-100 text-yellow-800",
  confirmed: "bg-blue-100 text-blue-800",
  preparing: "bg-purple-100 text-purple-800",
  ready: "bg-green-100 text-green-800",
  picked_up: "bg-indigo-100 text-indigo-800",
  delivering: "bg-orange-100 text-orange-800",
  delivered: "bg-emerald-100 text-emerald-800",
  cancelled: "bg-red-100 text-red-800",
};

const allStatuses = ["pending", "confirmed", "preparing", "ready", "picked_up", "delivering", "delivered", "cancelled"];

export default function Dashboard() {
  const { t, language } = useLanguage();
  const { isAuthenticated, user } = useAuth();

  const [activeTab, setActiveTab] = useState("overview");
  const [restaurantDialog, setRestaurantDialog] = useState(false);
  const [menuItemDialog, setMenuItemDialog] = useState(false);
  const [editRestaurant, setEditRestaurant] = useState<{ id: number; name: string; description?: string; address?: string; phone?: string; isOpen: boolean; deliveryFee: number } | null>(null);
  const [editMenuItem, setEditMenuItem] = useState<{ id: number; restaurantId: number; nameEn: string; nameSw: string; description?: string; descriptionSw?: string; price: number; category?: string; isAvailable: boolean } | null>(null);

  // Form states
  const [newRestaurant, setNewRestaurant] = useState({ name: "", description: "", address: "", phone: "", deliveryFee: 0 });
  const [newMenuItem, setNewMenuItem] = useState({ restaurantId: 0, nameEn: "", nameSw: "", description: "", descriptionSw: "", price: 0, category: "" });

  const { data: allOrders, refetch: refetchOrders } = trpc.orders.all.useQuery(undefined, { enabled: isAuthenticated });
  const { data: allRestaurants, refetch: refetchRestaurants } = trpc.restaurants.list.useQuery();
  const { data: categories } = trpc.categories.list.useQuery();
  const { data: ownerRegistrations, refetch: refetchOwners } = trpc.ownerRegistration.list.useQuery(undefined, { enabled: isAuthenticated });

  // Restaurant CRUD
  const createRestaurant = trpc.restaurants.create.useMutation({
    onSuccess: () => { refetchRestaurants(); setRestaurantDialog(false); setNewRestaurant({ name: "", description: "", address: "", phone: "", deliveryFee: 0 }); toast.success("Restaurant created"); },
    onError: () => toast.error(t("common.error")),
  });
  const updateRestaurant = trpc.restaurants.update.useMutation({
    onSuccess: () => { refetchRestaurants(); setEditRestaurant(null); toast.success("Restaurant updated"); },
    onError: () => toast.error(t("common.error")),
  });
  const deleteRestaurant = trpc.restaurants.delete.useMutation({
    onSuccess: () => { refetchRestaurants(); toast.success("Restaurant deleted"); },
    onError: () => toast.error(t("common.error")),
  });

  // Menu Item CRUD
  const createMenuItem = trpc.menuItems.create.useMutation({
    onSuccess: () => { refetchRestaurants(); setMenuItemDialog(false); setNewMenuItem({ ...newMenuItem, nameEn: "", nameSw: "", description: "", descriptionSw: "", price: 0, category: "" }); toast.success("Menu item created"); },
    onError: () => toast.error(t("common.error")),
  });
  const updateMenuItem = trpc.menuItems.update.useMutation({
    onSuccess: () => { refetchRestaurants(); setEditMenuItem(null); toast.success("Menu item updated"); },
    onError: () => toast.error(t("common.error")),
  });
  const deleteMenuItem = trpc.menuItems.delete.useMutation({
    onSuccess: () => { refetchRestaurants(); toast.success("Menu item deleted"); },
    onError: () => toast.error(t("common.error")),
  });

  // Owner registration management
  const updateOwnerStatus = trpc.ownerRegistration.updateStatus.useMutation({
    onSuccess: () => { refetchOwners(); toast.success("Status updated"); },
    onError: () => toast.error(t("common.error")),
  });

  // Order status update
  const updateOrderStatus = trpc.orders.updateStatus.useMutation({
    onSuccess: () => { refetchOrders(); toast.success("Status updated"); },
    onError: () => toast.error(t("common.error")),
  });

  const formatTzs = (amount: number) =>
    new Intl.NumberFormat("sw-TZ", { style: "currency", currency: "TZS", minimumFractionDigits: 0 }).format(amount);

  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <LayoutDashboard className="h-16 w-16 mx-auto text-muted-foreground/30 mb-4" />
          <p className="text-muted-foreground mb-4">Admin access required</p>
          <Button onClick={() => startLogin()}>{t("nav.login")}</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-xl border-b border-border/50">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2.5">
            <img src="/manus-storage/knjamasi_logo_974e872d.png" alt="K.NJAMASI" className="h-9 w-9 rounded-full" />
            <span className="font-display text-xl font-bold">Njamasi<span className="text-accent">Eats</span> <span className="text-sm font-normal text-muted-foreground ml-2">{t("dashboard.title")}</span></span>
          </div>
          <Button variant="outline" size="sm" onClick={() => window.location.href = "/"}>
            {t("common.back")}
          </Button>
        </div>
      </header>

      <main className="flex-1 py-8">
        <div className="container">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="bg-white border border-border/50">
              <TabsTrigger value="overview" className="gap-2"><LayoutDashboard className="h-4 w-4" /> {t("dashboard.overview")}</TabsTrigger>
              <TabsTrigger value="restaurants" className="gap-2"><Store className="h-4 w-4" /> {t("dashboard.restaurants")}</TabsTrigger>
              <TabsTrigger value="menu" className="gap-2"><ChefHat className="h-4 w-4" /> {t("dashboard.menuItems")}</TabsTrigger>
              <TabsTrigger value="orders" className="gap-2"><ShoppingCart className="h-4 w-4" /> {t("dashboard.orders")}</TabsTrigger>
              <TabsTrigger value="registrations" className="gap-2"><Users className="h-4 w-4" /> {language === "sw" ? "Maombi" : "Registrations"}</TabsTrigger>
            </TabsList>

            {/* Overview */}
            <TabsContent value="overview">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card className="border-border/50">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-primary/10"><Store className="h-5 w-5 text-primary" /></div>
                      <div>
                        <p className="text-sm text-muted-foreground">{t("dashboard.restaurants")}</p>
                        <p className="text-2xl font-bold">{allRestaurants?.length || 0}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card className="border-border/50">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-accent/10"><ShoppingCart className="h-5 w-5 text-accent" /></div>
                      <div>
                        <p className="text-sm text-muted-foreground">{t("dashboard.orders")}</p>
                        <p className="text-2xl font-bold">{allOrders?.length || 0}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card className="border-border/50">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-yellow-100"><Clock className="h-5 w-5 text-yellow-600" /></div>
                      <div>
                        <p className="text-sm text-muted-foreground">{t("tracking.pending")}</p>
                        <p className="text-2xl font-bold">{allOrders?.filter(o => o.status === "pending").length || 0}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card className="border-border/50">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-green-100"><CheckCircle className="h-5 w-5 text-green-600" /></div>
                      <div>
                        <p className="text-sm text-muted-foreground">{t("tracking.delivered")}</p>
                        <p className="text-2xl font-bold">{allOrders?.filter(o => o.status === "delivered").length || 0}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Recent Orders */}
              <Card className="mt-6 border-border/50">
                <CardHeader><CardTitle>{t("dashboard.orders")}</CardTitle></CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {allOrders?.slice(0, 5).map(order => (
                      <div key={order.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                        <div>
                          <span className="font-semibold">#{order.id}</span>
                          <span className="text-sm text-muted-foreground ml-2">{order.customerName}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge className={statusColors[order.status]}>{statusLabels[order.status]?.[language]}</Badge>
                          <span className="font-semibold text-primary">{formatTzs(order.totalAmount)}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Restaurants */}
            <TabsContent value="restaurants">
              <div className="flex items-center justify-between mb-6">
                <h2 className="font-display text-2xl font-bold">{t("dashboard.restaurants")}</h2>
                <Dialog open={restaurantDialog} onOpenChange={setRestaurantDialog}>
                  <DialogTrigger asChild>
                    <Button className="gap-2"><Plus className="h-4 w-4" /> {t("dashboard.addRestaurant")}</Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader><DialogTitle>{t("dashboard.addRestaurant")}</DialogTitle></DialogHeader>
                    <div className="space-y-4">
                      <div><Label>{t("dashboard.name")}</Label><Input value={newRestaurant.name} onChange={e => setNewRestaurant({ ...newRestaurant, name: e.target.value })} className="mt-1" /></div>
                      <div><Label>{t("dashboard.description")}</Label><Textarea value={newRestaurant.description} onChange={e => setNewRestaurant({ ...newRestaurant, description: e.target.value })} className="mt-1" /></div>
                      <div><Label>{t("dashboard.address")}</Label><Input value={newRestaurant.address} onChange={e => setNewRestaurant({ ...newRestaurant, address: e.target.value })} className="mt-1" /></div>
                      <div><Label>{t("dashboard.phone")}</Label><Input value={newRestaurant.phone} onChange={e => setNewRestaurant({ ...newRestaurant, phone: e.target.value })} className="mt-1" /></div>
                      <div><Label>{t("dashboard.deliveryFee")} (TZS)</Label><Input type="number" value={newRestaurant.deliveryFee} onChange={e => setNewRestaurant({ ...newRestaurant, deliveryFee: parseInt(e.target.value) || 0 })} className="mt-1" /></div>
                      <Button className="w-full" onClick={() => createRestaurant.mutate(newRestaurant)}>{t("dashboard.save")}</Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>

              <div className="space-y-3">
                {allRestaurants?.map(restaurant => (
                  <motion.div key={restaurant.id} layout className="flex items-center justify-between p-4 bg-white rounded-xl border border-border/50">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                        <Store className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium">{restaurant.name}</p>
                        <p className="text-xs text-muted-foreground">{restaurant.address || "No address"}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={restaurant.isOpen ? "default" : "secondary"}>{restaurant.isOpen ? t("dashboard.open") : t("dashboard.closed")}</Badge>
                      <span className="text-sm text-muted-foreground">{formatTzs(restaurant.deliveryFee)}</span>
                      <Button variant="ghost" size="icon" onClick={() => setEditRestaurant({ id: restaurant.id, name: restaurant.name, description: restaurant.description || "", address: restaurant.address || "", phone: restaurant.phone || "", isOpen: restaurant.isOpen, deliveryFee: restaurant.deliveryFee })}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="text-destructive" onClick={() => deleteRestaurant.mutate({ id: restaurant.id })}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* Edit Restaurant Dialog */}
              {editRestaurant && (
                <Dialog open={!!editRestaurant} onOpenChange={() => setEditRestaurant(null)}>
                  <DialogContent>
                    <DialogHeader><DialogTitle>{t("dashboard.editRestaurant")}</DialogTitle></DialogHeader>
                    <div className="space-y-4">
                      <div><Label>{t("dashboard.name")}</Label><Input value={editRestaurant.name} onChange={e => setEditRestaurant({ ...editRestaurant, name: e.target.value })} className="mt-1" /></div>
                      <div><Label>{t("dashboard.address")}</Label><Input value={editRestaurant.address} onChange={e => setEditRestaurant({ ...editRestaurant, address: e.target.value })} className="mt-1" /></div>
                      <div><Label>{t("dashboard.phone")}</Label><Input value={editRestaurant.phone} onChange={e => setEditRestaurant({ ...editRestaurant, phone: e.target.value })} className="mt-1" /></div>
                      <div><Label>{t("dashboard.deliveryFee")} (TZS)</Label><Input type="number" value={editRestaurant.deliveryFee} onChange={e => setEditRestaurant({ ...editRestaurant, deliveryFee: parseInt(e.target.value) || 0 })} className="mt-1" /></div>
                      <div className="flex items-center justify-between">
                        <Label>{t("dashboard.open")}</Label>
                        <Switch checked={editRestaurant.isOpen} onCheckedChange={v => setEditRestaurant({ ...editRestaurant, isOpen: v })} />
                      </div>
                      <Button className="w-full" onClick={() => updateRestaurant.mutate({ id: editRestaurant.id, name: editRestaurant.name, description: editRestaurant.description, address: editRestaurant.address, phone: editRestaurant.phone, isOpen: editRestaurant.isOpen, deliveryFee: editRestaurant.deliveryFee })}>{t("dashboard.save")}</Button>
                    </div>
                  </DialogContent>
                </Dialog>
              )}
            </TabsContent>

            {/* Menu Items - rendered as sub-component to avoid hooks-in-loop */}
            <TabsContent value="menu">
              <MenuItemsSection
                restaurants={allRestaurants || []}
                categories={categories || []}
                language={language}
                t={t}
                formatTzs={formatTzs}
                editMenuItem={editMenuItem}
                setEditMenuItem={setEditMenuItem}
                newMenuItem={newMenuItem}
                setNewMenuItem={setNewMenuItem}
                menuItemDialog={menuItemDialog}
                setMenuItemDialog={setMenuItemDialog}
                createMenuItem={createMenuItem}
                updateMenuItem={updateMenuItem}
                deleteMenuItem={deleteMenuItem}
              />
            </TabsContent>

            {/* Owner Registrations */}
            <TabsContent value="registrations">
              <RegistrationsSection
                registrations={ownerRegistrations || []}
                language={language}
                t={t}
                updateOwnerStatus={updateOwnerStatus}
              />
            </TabsContent>

            {/* Orders */}
            <TabsContent value="orders">
              <h2 className="font-display text-2xl font-bold mb-6">{t("dashboard.orders")}</h2>
              <div className="space-y-4">
                {allOrders?.map(order => (
                  <Card key={order.id} className="border-border/50">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <span className="font-bold">#{order.id}</span>
                          <span className="text-sm text-muted-foreground ml-2">{order.customerName}</span>
                          <span className="text-xs text-muted-foreground ml-2 block">{order.customerPhone}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge className={statusColors[order.status]}>{statusLabels[order.status]?.[language]}</Badge>
                          <Select
                            defaultValue={order.status}
                            onValueChange={(v) => updateOrderStatus.mutate({ id: order.id, status: v as any })}
                          >
                            <SelectTrigger className="w-[140px] h-8 text-xs"><SelectValue /></SelectTrigger>
                            <SelectContent>
                              {allStatuses.map(s => <SelectItem key={s} value={s}>{statusLabels[s]?.[language]}</SelectItem>)}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground mb-3">
                        <span className="flex items-center gap-1">
                          {order.deliveryMethod === "self_pickup" ? <MapPin className="h-3 w-3" /> :
                           order.deliveryMethod === "restaurant_delivery" ? <Truck className="h-3 w-3" /> : <Bike className="h-3 w-3" />}
                          {order.deliveryMethod}
                        </span>
                        <span>{order.paymentMethod}</span>
                        <span>{new Date(order.createdAt).toLocaleString()}</span>
                      </div>
                      {order.deliveryAddress && <p className="text-xs text-muted-foreground mb-2">{order.deliveryAddress}</p>}
                      <Separator className="mb-2" />
                      <div className="space-y-1">
                        {order.items?.map(item => (
                          <div key={item.id} className="flex justify-between text-sm">
                            <span>{language === "sw" ? item.itemNameSw : item.itemNameEn} x{item.quantity}</span>
                            <span className="font-medium">{formatTzs(item.totalPrice)}</span>
                          </div>
                        ))}
                      </div>
                      <div className="flex justify-between mt-2 pt-2 border-t border-border/50">
                        <span className="text-sm text-muted-foreground">{order.items?.length} {t("cart.items")}</span>
                        <span className="font-bold text-primary">{formatTzs(order.totalAmount)}</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
}

// Separate component for menu items to avoid hooks-in-loop
function MenuItemsSection({
  restaurants,
  categories,
  language,
  t,
  formatTzs,
  editMenuItem,
  setEditMenuItem,
  newMenuItem,
  setNewMenuItem,
  menuItemDialog,
  setMenuItemDialog,
  createMenuItem,
  updateMenuItem,
  deleteMenuItem,
}: {
  restaurants: any[];
  categories: any[];
  language: "en" | "sw";
  t: (key: string) => string;
  formatTzs: (amount: number) => string;
  editMenuItem: { id: number; restaurantId: number; nameEn: string; nameSw: string; description?: string; descriptionSw?: string; price: number; category?: string; isAvailable: boolean } | null;
  setEditMenuItem: React.Dispatch<React.SetStateAction<any>>;
  newMenuItem: { restaurantId: number; nameEn: string; nameSw: string; description: string; descriptionSw: string; price: number; category: string };
  setNewMenuItem: React.Dispatch<React.SetStateAction<any>>;
  menuItemDialog: boolean;
  setMenuItemDialog: React.Dispatch<React.SetStateAction<boolean>>;
  createMenuItem: any;
  updateMenuItem: any;
  deleteMenuItem: any;
}) {
  // Fetch menu items for each restaurant (max 10 hooks)
  const first10 = restaurants.slice(0, 10);
  const menuItemsQueries = first10.map(r =>
    trpc.menuItems.getByRestaurant.useQuery({ restaurantId: r.id })
  );

  const menuItemsByRestaurant: { [key: number]: any[] } = {};
  first10.forEach((r, idx) => {
    menuItemsByRestaurant[r.id] = menuItemsQueries[idx]?.data || [];
  });

  return (
    <>
      <div className="flex items-center justify-between mb-6">
        <h2 className="font-display text-2xl font-bold">{t("dashboard.menuItems")}</h2>
        <Dialog open={menuItemDialog} onOpenChange={setMenuItemDialog}>
          <DialogTrigger asChild>
            <Button className="gap-2"><Plus className="h-4 w-4" /> {t("dashboard.addMenuItem")}</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>{t("dashboard.addMenuItem")}</DialogTitle></DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Restaurant</Label>
                <Select value={String(newMenuItem.restaurantId)} onValueChange={v => setNewMenuItem({ ...newMenuItem, restaurantId: parseInt(v) })}>
                  <SelectTrigger className="mt-1"><SelectValue placeholder="Select restaurant" /></SelectTrigger>
                  <SelectContent>
                    {restaurants.map(r => <SelectItem key={r.id} value={String(r.id)}>{r.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div><Label>Name (English)</Label><Input value={newMenuItem.nameEn} onChange={e => setNewMenuItem({ ...newMenuItem, nameEn: e.target.value })} className="mt-1" /></div>
              <div><Label>Name (Swahili)</Label><Input value={newMenuItem.nameSw} onChange={e => setNewMenuItem({ ...newMenuItem, nameSw: e.target.value })} className="mt-1" /></div>
              <div><Label>Description (English)</Label><Textarea value={newMenuItem.description} onChange={e => setNewMenuItem({ ...newMenuItem, description: e.target.value })} className="mt-1" /></div>
              <div><Label>Description (Swahili)</Label><Textarea value={newMenuItem.descriptionSw} onChange={e => setNewMenuItem({ ...newMenuItem, descriptionSw: e.target.value })} className="mt-1" /></div>
              <div><Label>{t("dashboard.price")}</Label><Input type="number" value={newMenuItem.price} onChange={e => setNewMenuItem({ ...newMenuItem, price: parseInt(e.target.value) || 0 })} className="mt-1" /></div>
              <div><Label>{t("dashboard.category")}</Label><Input value={newMenuItem.category} onChange={e => setNewMenuItem({ ...newMenuItem, category: e.target.value })} className="mt-1" /></div>
              <Button className="w-full" onClick={() => createMenuItem.mutate(newMenuItem)}>{t("dashboard.save")}</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Group by restaurant */}
      {restaurants.map(restaurant => {
        const items = menuItemsByRestaurant[restaurant.id] || [];
        return (
          <div key={restaurant.id} className="mb-6">
            <h3 className="font-display text-lg font-semibold mb-3">{restaurant.name}</h3>
            <div className="space-y-2">
              {items.map((item: any) => (
                <div key={item.id} className="flex items-center justify-between p-3 bg-white rounded-lg border border-border/50">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-accent/10 flex items-center justify-center">
                      <Package className="h-4 w-4 text-accent" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">{language === "sw" && item.nameSw ? item.nameSw : item.nameEn}</p>
                      <p className="text-xs text-muted-foreground">{item.category || "Uncategorized"} — {formatTzs(item.price)}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant={item.isAvailable ? "default" : "secondary"} className="text-xs">{item.isAvailable ? t("dashboard.available") : t("menu.unavailable")}</Badge>
                    <Button variant="ghost" size="icon" onClick={() => setEditMenuItem({ id: item.id, restaurantId: item.restaurantId, nameEn: item.nameEn, nameSw: item.nameSw, description: item.description || "", descriptionSw: item.descriptionSw || "", price: item.price, category: item.category || "", isAvailable: item.isAvailable })}>
                      <Pencil className="h-3.5 w-3.5" />
                    </Button>
                    <Button variant="ghost" size="icon" className="text-destructive" onClick={() => deleteMenuItem.mutate({ id: item.id })}>
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      })}

      {/* Edit Menu Item Dialog */}
      {editMenuItem && (
        <Dialog open={!!editMenuItem} onOpenChange={() => setEditMenuItem(null)}>
          <DialogContent>
            <DialogHeader><DialogTitle>{t("dashboard.editMenuItem")}</DialogTitle></DialogHeader>
            <div className="space-y-4">
              <div><Label>Name (English)</Label><Input value={editMenuItem.nameEn} onChange={e => setEditMenuItem({ ...editMenuItem, nameEn: e.target.value })} className="mt-1" /></div>
              <div><Label>Name (Swahili)</Label><Input value={editMenuItem.nameSw} onChange={e => setEditMenuItem({ ...editMenuItem, nameSw: e.target.value })} className="mt-1" /></div>
              <div><Label>Price (TZS)</Label><Input type="number" value={editMenuItem.price} onChange={e => setEditMenuItem({ ...editMenuItem, price: parseInt(e.target.value) || 0 })} className="mt-1" /></div>
              <div><Label>{t("dashboard.category")}</Label><Input value={editMenuItem.category} onChange={e => setEditMenuItem({ ...editMenuItem, category: e.target.value })} className="mt-1" /></div>
              <div className="flex items-center justify-between">
                <Label>{t("dashboard.available")}</Label>
                <Switch checked={editMenuItem.isAvailable} onCheckedChange={v => setEditMenuItem({ ...editMenuItem, isAvailable: v })} />
              </div>
              <Button className="w-full" onClick={() => updateMenuItem.mutate({ id: editMenuItem.id, nameEn: editMenuItem.nameEn, nameSw: editMenuItem.nameSw, description: editMenuItem.description, descriptionSw: editMenuItem.descriptionSw, price: editMenuItem.price, category: editMenuItem.category, isAvailable: editMenuItem.isAvailable })}>{t("dashboard.save")}</Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}
// Owner Registration Section
function RegistrationsSection({
  registrations,
  language,
  t,
  updateOwnerStatus,
}: {
  registrations: any[];
  language: "en" | "sw";
  t: (key: string) => string;
  updateOwnerStatus: any;
}) {
  if (registrations.length === 0) {
    return (
      <div>
        <h2 className="font-display text-2xl font-bold mb-6">
          {language === "sw" ? "Maombi ya Mgahawa" : "Restaurant Applications"}
        </h2>
        <Card className="border-border/50">
          <CardContent className="p-12 text-center">
            <Users className="h-12 w-12 mx-auto text-muted-foreground/30 mb-3" />
            <p className="text-muted-foreground">
              {language === "sw" ? "Hakuna maombi bado" : "No registrations yet"}
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const ownerStatusLabels: Record<string, { en: string; sw: string }> = {
    pending: { en: "Pending", sw: "Inasubiri" },
    approved: { en: "Approved", sw: "Imekubaliwa" },
    rejected: { en: "Rejected", sw: "Imekataliwa" },
  };

  const ownerStatusColors: Record<string, string> = {
    pending: "bg-yellow-100 text-yellow-800",
    approved: "bg-green-100 text-green-800",
    rejected: "bg-red-100 text-red-800",
  };

  const pendingCount = registrations.filter((r: any) => r.status === "pending").length;

  if (registrations.length === 0) {
    return (
      <div>
        <h2 className="font-display text-2xl font-bold mb-6">
          {language === "sw" ? "Maombi ya Mgahawa" : "Restaurant Applications"}
        </h2>
        <Card className="border-border/50">
          <CardContent className="p-12 text-center">
            <Users className="h-12 w-12 mx-auto text-muted-foreground/30 mb-3" />
            <p className="text-muted-foreground">
              {language === "sw" ? "Hakuna maombi bado" : "No registrations yet"}
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="font-display text-2xl font-bold">
          {language === "sw" ? "Maombi ya Mgahawa" : "Restaurant Applications"}
        </h2>
        {pendingCount > 0 && (
          <Badge className="bg-yellow-100 text-yellow-800 text-sm px-3 py-1">
            {pendingCount} {language === "sw" ? "Inasubiri" : "Pending"}
          </Badge>
        )}
      </div>

      <div className="space-y-3">
        {registrations.map((reg: any) => (
          <Card key={reg.id} className="border-border/50">
            <CardContent className="p-5">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Store className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-semibold">{reg.restaurantName}</p>
                    <p className="text-xs text-muted-foreground">{reg.cuisineType || (language === "sw" ? "Aina haijafafanuliwa" : "No cuisine type")}</p>
                  </div>
                </div>
                <Badge className={ownerStatusColors[reg.status]}>
                  {ownerStatusLabels[reg.status]?.[language]}
                </Badge>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-xs text-muted-foreground">{language === "sw" ? "Mmiliki" : "Owner"}</p>
                  <p className="font-medium">{reg.ownerName}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">{language === "sw" ? "Barua Pepe" : "Email"}</p>
                  <p className="font-medium">{reg.ownerEmail}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">{language === "sw" ? "Simu" : "Phone"}</p>
                  <p className="font-medium">{reg.ownerPhone}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">{language === "sw" ? "Usafirishaji" : "Delivery"}</p>
                  <p className="font-medium">{reg.deliveryMethod || "self_pickup"}</p>
                </div>
              </div>

              <p className="text-xs text-muted-foreground mt-3 mb-1">{language === "sw" ? "Anwani" : "Address"}</p>
              <p className="text-sm text-muted-foreground">{reg.restaurantAddress}</p>

              {reg.restaurantDescription && (
                <p className="text-sm text-muted-foreground mt-2 italic">"{reg.restaurantDescription}"</p>
              )}

              <p className="text-xs text-muted-foreground mt-2">
                {language === "sw" ? "Iliyotumwa" : "Submitted"} {new Date(reg.createdAt).toLocaleDateString()}
              </p>

              {reg.status === "pending" && (
                <div className="flex gap-2 mt-4 pt-3 border-t border-border/50">
                  <Button
                    size="sm"
                    className="gap-1.5 bg-green-600 hover:bg-green-700 text-white"
                    onClick={() => updateOwnerStatus.mutate({ id: reg.id, status: "approved" })}
                  >
                    <FileCheck className="h-4 w-4" />
                    {language === "sw" ? "Kubali" : "Approve"}
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="gap-1.5 text-red-600 border-red-200 hover:bg-red-50"
                    onClick={() => updateOwnerStatus.mutate({ id: reg.id, status: "rejected" })}
                  >
                    <FileX className="h-4 w-4" />
                    {language === "sw" ? "Kataa" : "Reject"}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
