import { useLanguage } from "@/contexts/LanguageContext";
import Navigation from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { MapPin, Clock, CreditCard, ShoppingBag, ChevronRight, Star, Users, Store } from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";

export default function Home() {
  const { t, language } = useLanguage();

  const steps = [
    { icon: ShoppingBag, title: t("landing.step1Title"), desc: t("landing.step1Desc") },
    { icon: Star, title: t("landing.step2Title"), desc: t("landing.step2Desc") },
    { icon: MapPin, title: t("landing.step3Title"), desc: t("landing.step3Desc") },
    { icon: CreditCard, title: t("landing.step4Title"), desc: t("landing.step4Desc") },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-accent/5" />
        <div className="absolute top-20 left-10 w-72 h-72 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-10 right-10 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />
        
        <div className="container relative py-20 md:py-32">
          <div className="max-w-2xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/8 text-primary text-sm font-medium mb-6">
                <Clock className="h-4 w-4" />
                <span>{language === "sw" ? "Chakula Tamu, Kinapelekwa Haraka" : "Delicious Food, Delivered Fast"}</span>
              </div>
            </motion.div>

            <motion.h1
              className="font-display text-4xl md:text-6xl font-bold leading-tight mb-6 text-foreground"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              {t("landing.title")}
            </motion.h1>

            <motion.p
              className="text-lg text-muted-foreground mb-10 max-w-lg mx-auto leading-relaxed"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              {t("landing.subtitle")}
            </motion.p>

            <motion.div
              className="flex flex-col sm:flex-row items-center justify-center gap-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <Link href="/restaurants">
                <Button size="lg" className="gap-2 px-8 text-base shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-primary/30 transition-shadow duration-300">
                  {t("landing.cta")}
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </Link>
              <Link href="/restaurants">
                <Button variant="outline" size="lg" className="gap-2 px-8 text-base bg-white">
                  {t("landing.browse")}
                </Button>
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-white">
        <div className="container">
          <motion.h2
            className="font-display text-3xl md:text-4xl font-bold text-center mb-4 text-foreground"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
          >
            {t("landing.howItWorks")}
          </motion.h2>
          <p className="text-center text-muted-foreground mb-14 max-w-md mx-auto">
            {language === "sw"
              ? "Agiza chakula kutoka kwenye migahawa inayopendwa kwa hatua nne rahisi"
              : "Order food from your favorite restaurants in four simple steps"}
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {steps.map((step, i) => (
              <motion.div
                key={i}
                className="relative p-6 rounded-2xl bg-background border border-border/50 hover:border-primary/20 hover:shadow-lg transition-all duration-300 group"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-primary/10 text-primary mb-4 group-hover:bg-primary group-hover:text-white transition-colors duration-300">
                  <step.icon className="h-6 w-6" />
                </div>
                <div className="absolute top-6 right-6 text-4xl font-bold text-primary/10 font-display">
                  {i + 1}
                </div>
                <h3 className="font-display text-lg font-semibold mb-2 text-foreground">
                  {step.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {step.desc}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Partner With Us CTA */}
      <section className="py-20 bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-accent/10 text-accent text-sm font-medium mb-6">
                <Store className="h-4 w-4" />
                <span>{language === "sw" ? "Mmiliki wa Mgahawa?" : "Restaurant Owner?"}</span>
              </div>

              <h2 className="font-display text-3xl md:text-4xl font-bold mb-4 text-foreground">
                {language === "sw"
                  ? "Jiunge na NjamasiEats Leo"
                  : "Join NjamasiEats Today"}
              </h2>

              <p className="text-lg text-muted-foreground mb-8 max-w-xl mx-auto leading-relaxed">
                {language === "sw"
                  ? "Ongeza wateja wako na kuongeza mauzo kwa kutoa chakula chako kupitia NjamasiEats. Jiandikishe leo na uanze kupokea maagizo."
                  : "Grow your customer base and boost sales by offering your food on NjamasiEats. Register today and start receiving orders."}
              </p>

              <motion.div
                className="flex flex-col sm:flex-row items-center justify-center gap-4"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
              >
                <Link href="/register-restaurant">
                  <Button size="lg" className="gap-2 px-8 text-base shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-primary/30 transition-shadow duration-300">
                    <Users className="h-4 w-4" />
                    {language === "sw" ? "Jiandikishe Mgahawa" : "Register Your Restaurant"}
                  </Button>
                </Link>
                <p className="text-sm text-muted-foreground">
                  {language === "sw"
                    ? "Bure kujiandikisha — malipo ya tume kidogo kwa kila agizo"
                    : "Free registration — small commission per order"}
                </p>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 bg-white border-t border-border/50">
        <div className="container text-center">
          <div className="flex items-center justify-center gap-2 mb-3">
            <img
              src="/manus-storage/knjamasi_logo_974e872d.png"
              alt="K.NJAMASI"
              className="h-6 w-6 rounded-full"
            />
            <span className="font-display text-sm font-semibold">NjamasiEats</span>
          </div>
          <p className="text-xs text-muted-foreground">
            {t("common.ownedBy")} — Singida, Tanzania
          </p>
        </div>
      </footer>
    </div>
  );
}
