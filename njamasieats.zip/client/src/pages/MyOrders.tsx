import { useLanguage } from "@/contexts/LanguageContext";
import Navigation from "@/components/Navigation";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { ShoppingBag, ArrowLeft, ChevronRight } from "lucide-react";
import { Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";

const statusLabels: Record<string, { en: string; sw: string }> = {
  pending: { en: "Pending", sw: "Inasubiri" },
  confirmed: { en: "Confirmed", sw: "Imethibitishwa" },
  preparing: { en: "Preparing", sw: "Inatayarishwa" },
  ready: { en: "Ready", sw: "Imeandaliwa" },
  picked_up: { en: "Picked Up", sw: "Imechukuliwa" },
  delivering: { en: "Delivering", sw: "Inasafirishwa" },
  delivered: { en: "Delivered", sw: "Imefika" },
  cancelled: { en: "Cancelled", sw: "Imeghairiwa" },
};

export default function MyOrders() {
  const { t, language } = useLanguage();
  const { isAuthenticated } = useAuth();
  const { data: orders, isLoading } = trpc.orders.myOrders.useQuery();

  const formatTzs = (amount: number) =>
    new Intl.NumberFormat("sw-TZ", { style: "currency", currency: "TZS", minimumFractionDigits: 0 }).format(amount);

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navigation />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <p className="text-muted-foreground mb-4">{t("orders.signInRequired")}</p>
            <Button onClick={() => startLogin()}>{t("nav.login")}</Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />

      <main className="flex-1 py-8">
        <div className="container max-w-2xl">
          <Link href="/">
            <Button variant="ghost" size="sm" className="mb-6 text-muted-foreground">
              <ArrowLeft className="h-4 w-4 mr-1" /> {t("common.back")}
            </Button>
          </Link>

          <h1 className="font-display text-3xl font-bold text-foreground mb-8">
            {t("nav.orders")}
          </h1>

          {isLoading ? (
            <div className="space-y-4">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="h-32 rounded-xl bg-muted animate-pulse" />
              ))}
            </div>
          ) : !orders || orders.length === 0 ? (
            <div className="text-center py-20">
              <ShoppingBag className="h-16 w-16 mx-auto text-muted-foreground/30 mb-4" />
              <p className="text-muted-foreground text-lg">{t("orders.noOrders")}</p>
            </div>
          ) : (
            <div className="space-y-4">
              {orders.map((order) => (
                <Link key={order.id} href={`/orders/${order.id}`}>
                  <Card className="border-border/50 hover:border-primary/20 hover:shadow-md transition-all duration-200 cursor-pointer">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-semibold">#{order.id}</span>
                            <Badge
                              variant={order.status === "delivered" ? "default" : order.status === "cancelled" ? "destructive" : "secondary"}
                              className="text-xs"
                            >
                              {statusLabels[order.status]?.[language] || order.status}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            {order.restaurant?.name || "Restaurant"} — {new Date(order.createdAt).toLocaleString()}
                          </p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {order.items?.length || 0} {t("cart.items")}
                          </p>
                        </div>
                        <div className="text-right flex items-center gap-2">
                          <div>
                            <p className="font-bold text-primary">{formatTzs(order.totalAmount)}</p>
                          </div>
                          <ChevronRight className="h-5 w-5 text-muted-foreground" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
