import { useLanguage } from "@/contexts/LanguageContext";
import { useCart } from "@/contexts/CartContext";
import { useAuth } from "@/_core/hooks/useAuth";
import Navigation from "@/components/Navigation";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { ArrowLeft, CheckCircle, MapPin, Truck, Bike, CreditCard, Banknote, Smartphone } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { toast } from "sonner";

type DeliveryMethod = "self_pickup" | "restaurant_delivery" | "independent_rider";
type PaymentMethod = "mpesa" | "airtel_money" | "cash_on_delivery";

export default function Checkout() {
  const { t, language } = useLanguage();
  const { items, getSubtotal, clearCart } = useCart();
  const { isAuthenticated, user } = useAuth();
  const [, setLocation] = useLocation();

  const [customerName, setCustomerName] = useState(user?.name || "");
  const [customerPhone, setCustomerPhone] = useState("");
  const [deliveryAddress, setDeliveryAddress] = useState("");
  const [notes, setNotes] = useState("");
  const [deliveryMethod, setDeliveryMethod] = useState<DeliveryMethod>("self_pickup");
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("cash_on_delivery");
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [newOrderId, setNewOrderId] = useState<number | null>(null);

  const subtotal = getSubtotal();

  const deliveryFees: Record<DeliveryMethod, number> = {
    self_pickup: 0,
    restaurant_delivery: items.length > 0 ? 3000 : 0,
    independent_rider: items.length > 0 ? 5000 : 0,
  };

  const createOrder = trpc.orders.create.useMutation({
    onSuccess: (data) => {
      setOrderPlaced(true);
      setNewOrderId(data.orderId);
      clearCart();
    },
    onError: () => {
      toast.error(t("common.error"));
    },
  });

  const formatTzs = (amount: number) =>
    new Intl.NumberFormat("sw-TZ", { style: "currency", currency: "TZS", minimumFractionDigits: 0 }).format(amount);

  const total = subtotal + deliveryFees[deliveryMethod];

  const handlePlaceOrder = () => {
    if (!isAuthenticated) {
      toast.error("Please sign in to place an order");
      return;
    }
    if (!customerName || !customerPhone) {
      toast.error("Please fill in your name and phone number");
      return;
    }
    if ((deliveryMethod === "restaurant_delivery" || deliveryMethod === "independent_rider") && !deliveryAddress) {
      toast.error("Please provide a delivery address");
      return;
    }
    if (items.length === 0) return;

    const firstItem = items[0];
    createOrder.mutate({
      restaurantId: firstItem.restaurantId,
      deliveryMethod,
      paymentMethod,
      totalAmount: total,
      deliveryFee: deliveryFees[deliveryMethod],
      customerName,
      customerPhone,
      deliveryAddress: deliveryAddress || undefined,
      notes: notes || undefined,
      items: items.map(item => ({
        menuItemId: item.menuItemId,
        itemNameEn: item.itemNameEn,
        itemNameSw: item.itemNameSw,
        quantity: item.quantity,
        unitPrice: item.price,
        totalPrice: item.price * item.quantity,
      })),
    });
  };

  if (orderPlaced && newOrderId) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navigation />
        <main className="flex-1 flex items-center justify-center py-20">
          <motion.div
            className="text-center max-w-md mx-auto"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
          >
            <CheckCircle className="h-20 w-20 mx-auto text-success mb-6" />
            <h1 className="font-display text-3xl font-bold text-foreground mb-4">
              {t("checkout.orderPlaced")}
            </h1>
            <p className="text-muted-foreground mb-8">
              {t("checkout.orderSuccess")}
            </p>
            <Link href={`/orders/${newOrderId}`}>
              <Button size="lg" className="gap-2">{t("checkout.trackOrder")}</Button>
            </Link>
          </motion.div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />

      <main className="flex-1 py-8">
        <div className="container max-w-2xl">
          <Link href="/cart">
            <Button variant="ghost" size="sm" className="mb-6 text-muted-foreground">
              <ArrowLeft className="h-4 w-4 mr-1" /> {t("common.back")}
            </Button>
          </Link>

          <h1 className="font-display text-3xl font-bold text-foreground mb-8">
            {t("checkout.title")}
          </h1>

          {/* Customer Info */}
          <div className="bg-white rounded-xl border border-border/50 p-6 mb-6">
            <h2 className="font-display text-lg font-semibold mb-4">{t("checkout.customerInfo")}</h2>
            <div className="space-y-4">
              <div>
                <Label>{t("checkout.name")}</Label>
                <Input value={customerName} onChange={e => setCustomerName(e.target.value)} className="mt-1" />
              </div>
              <div>
                <Label>{t("checkout.phone")}</Label>
                <Input value={customerPhone} onChange={e => setCustomerPhone(e.target.value)} placeholder="+255..." className="mt-1" />
              </div>
              {(deliveryMethod === "restaurant_delivery" || deliveryMethod === "independent_rider") && (
                <div>
                  <Label>{t("checkout.address")}</Label>
                  <Input value={deliveryAddress} onChange={e => setDeliveryAddress(e.target.value)} className="mt-1" />
                </div>
              )}
              <div>
                <Label>{t("checkout.notes")}</Label>
                <Textarea value={notes} onChange={e => setNotes(e.target.value)} className="mt-1" rows={2} />
              </div>
            </div>
          </div>

          {/* Delivery Method */}
          <div className="bg-white rounded-xl border border-border/50 p-6 mb-6">
            <h2 className="font-display text-lg font-semibold mb-4">{t("checkout.deliveryMethod")}</h2>
            <RadioGroup value={deliveryMethod} onValueChange={(v) => setDeliveryMethod(v as DeliveryMethod)} className="space-y-3">
              <div className={`flex items-center gap-4 p-4 rounded-lg border-2 cursor-pointer transition-colors
                ${deliveryMethod === "self_pickup" ? "border-primary bg-primary/5" : "border-border/50"}`}>
                <RadioGroupItem value="self_pickup" id="self_pickup" />
                <MapPin className="h-5 w-5 text-primary" />
                <div className="flex-1">
                  <Label htmlFor="self_pickup" className="font-medium cursor-pointer">{t("checkout.selfPickup")}</Label>
                  <p className="text-xs text-muted-foreground">Free</p>
                </div>
                <span className="text-sm font-semibold text-success">{formatTzs(0)}</span>
              </div>

              <div className={`flex items-center gap-4 p-4 rounded-lg border-2 cursor-pointer transition-colors
                ${deliveryMethod === "restaurant_delivery" ? "border-primary bg-primary/5" : "border-border/50"}`}>
                <RadioGroupItem value="restaurant_delivery" id="restaurant_delivery" />
                <Truck className="h-5 w-5 text-primary" />
                <div className="flex-1">
                  <Label htmlFor="restaurant_delivery" className="font-medium cursor-pointer">{t("checkout.restaurantDelivery")}</Label>
                  <p className="text-xs text-muted-foreground">1-3 km range</p>
                </div>
                <span className="text-sm font-semibold">{formatTzs(3000)}</span>
              </div>

              <div className={`flex items-center gap-4 p-4 rounded-lg border-2 cursor-pointer transition-colors
                ${deliveryMethod === "independent_rider" ? "border-primary bg-primary/5" : "border-border/50"}`}>
                <RadioGroupItem value="independent_rider" id="independent_rider" />
                <Bike className="h-5 w-5 text-primary" />
                <div className="flex-1">
                  <Label htmlFor="independent_rider" className="font-medium cursor-pointer">{t("checkout.independentRider")}</Label>
                  <p className="text-xs text-muted-foreground">Wider range</p>
                </div>
                <span className="text-sm font-semibold">{formatTzs(5000)}</span>
              </div>
            </RadioGroup>
          </div>

          {/* Payment Method */}
          <div className="bg-white rounded-xl border border-border/50 p-6 mb-6">
            <h2 className="font-display text-lg font-semibold mb-4">{t("checkout.paymentMethod")}</h2>
            <RadioGroup value={paymentMethod} onValueChange={(v) => setPaymentMethod(v as PaymentMethod)} className="space-y-3">
              <div className={`flex items-center gap-4 p-4 rounded-lg border-2 cursor-pointer transition-colors
                ${paymentMethod === "mpesa" ? "border-primary bg-primary/5" : "border-border/50"}`}>
                <RadioGroupItem value="mpesa" id="mpesa" />
                <Smartphone className="h-5 w-5 text-success" />
                <div className="flex-1">
                  <Label htmlFor="mpesa" className="font-medium cursor-pointer">{t("checkout.mpesa")}</Label>
                  <p className="text-xs text-muted-foreground">Pay via M-Pesa</p>
                </div>
              </div>

              <div className={`flex items-center gap-4 p-4 rounded-lg border-2 cursor-pointer transition-colors
                ${paymentMethod === "airtel_money" ? "border-primary bg-primary/5" : "border-border/50"}`}>
                <RadioGroupItem value="airtel_money" id="airtel_money" />
                <Smartphone className="h-5 w-5 text-accent" />
                <div className="flex-1">
                  <Label htmlFor="airtel_money" className="font-medium cursor-pointer">{t("checkout.airtelMoney")}</Label>
                  <p className="text-xs text-muted-foreground">Pay via Airtel Money</p>
                </div>
              </div>

              <div className={`flex items-center gap-4 p-4 rounded-lg border-2 cursor-pointer transition-colors
                ${paymentMethod === "cash_on_delivery" ? "border-primary bg-primary/5" : "border-border/50"}`}>
                <RadioGroupItem value="cash_on_delivery" id="cash_on_delivery" />
                <Banknote className="h-5 w-5 text-warning" />
                <div className="flex-1">
                  <Label htmlFor="cash_on_delivery" className="font-medium cursor-pointer">{t("checkout.cashOnDelivery")}</Label>
                  <p className="text-xs text-muted-foreground">Pay when you receive</p>
                </div>
              </div>
            </RadioGroup>
          </div>

          {/* Order Summary */}
          <div className="bg-white rounded-xl border border-border/50 p-6 mb-6">
            <h2 className="font-display text-lg font-semibold mb-4">{t("cart.title")}</h2>
            <div className="space-y-2 mb-4">
              {items.map(item => (
                <div key={item.menuItemId} className="flex justify-between text-sm">
                  <span className="text-muted-foreground">
                    {language === "sw" ? item.itemNameSw : item.itemNameEn} x{item.quantity}
                  </span>
                  <span className="font-medium">{formatTzs(item.price * item.quantity)}</span>
                </div>
              ))}
            </div>
            <Separator className="mb-3" />
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">{t("cart.subtotal")}</span>
                <span>{formatTzs(subtotal)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">{t("cart.deliveryFee")}</span>
                <span>{formatTzs(deliveryFees[deliveryMethod])}</span>
              </div>
              <div className="flex justify-between text-lg font-bold pt-2 border-t border-border/50">
                <span>{t("cart.total")}</span>
                <span className="text-primary">{formatTzs(total)}</span>
              </div>
            </div>
          </div>

          {/* Place Order */}
          <Button
            size="lg"
            className="w-full gap-2 py-6 text-base shadow-lg shadow-primary/20"
            onClick={handlePlaceOrder}
            disabled={createOrder.isPending}
          >
            {createOrder.isPending ? t("common.loading") : (
              <>
                <CreditCard className="h-5 w-5" />
                {t("checkout.placeOrder")}
              </>
            )}
          </Button>
        </div>
      </main>
    </div>
  );
}
