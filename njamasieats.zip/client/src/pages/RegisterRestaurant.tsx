import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/_core/hooks/useAuth";
import Navigation from "@/components/Navigation";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, Store, CheckCircle, Users, Phone, Mail, MapPin, Utensils } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { startLogin } from "@/const";

export default function RegisterRestaurant() {
  const { t, language } = useLanguage();
  const { isAuthenticated } = useAuth();
  const [submitted, setSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [form, setForm] = useState({
    ownerName: "",
    ownerEmail: "",
    ownerPhone: "",
    restaurantName: "",
    restaurantAddress: "",
    restaurantPhone: "",
    restaurantDescription: "",
    cuisineType: "",
    deliveryMethod: "self_pickup",
  });

  const registerMutation = trpc.ownerRegistration.register.useMutation({
    onSuccess: () => {
      setSubmitted(true);
      setIsSubmitting(false);
      toast.success(
        language === "sw"
          ? "Maombi yako yametumwa! Tutakuchunguza na kukujulisha."
          : "Your application has been submitted! We will review and notify you."
      );
    },
    onError: () => {
      setIsSubmitting(false);
      toast.error(
        language === "sw"
          ? "Hitilafu imetokea. Tafadhali jaribu tena."
          : "An error occurred. Please try again."
      );
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.ownerName || !form.ownerEmail || !form.ownerPhone || !form.restaurantName || !form.restaurantAddress) {
      toast.error(
        language === "sw"
          ? "Tafadhali jaza sehemu zote zinazohitajika"
          : "Please fill in all required fields"
      );
      return;
    }
    setIsSubmitting(true);
    registerMutation.mutate(form);
  };

  const updateForm = (field: string, value: string) => {
    setForm(prev => ({ ...prev, [field]: value }));
  };

  if (submitted) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navigation />
        <main className="flex-1 flex items-center justify-center py-12">
          <div className="container max-w-lg">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center"
            >
              <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="h-10 w-10 text-green-600" />
              </div>
              <h1 className="font-display text-3xl font-bold text-foreground mb-4">
                {language === "sw" ? "Asante Sana!" : "Thank You!"}
              </h1>
              <p className="text-muted-foreground text-lg mb-6 leading-relaxed">
                {language === "sw"
                  ? "Maombi yako ya kujiandikisha mgahawa yamepokelewa. Tutakuchunguza na kukujulisha hivi karibuni kupitia barua pepe au simu yako."
                  : "Your restaurant registration application has been received. We will review it and notify you soon via email or phone."}
              </p>
              <div className="space-y-3">
                <Link href="/restaurants">
                  <Button className="w-full" size="lg">
                    {language === "sw" ? "Angalia Migahawa" : "Browse Restaurants"}
                  </Button>
                </Link>
                <Link href="/">
                  <Button variant="ghost" className="w-full">
                    {t("common.back")}
                  </Button>
                </Link>
              </div>
            </motion.div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />

      <main className="flex-1 py-8 md:py-12">
        <div className="container max-w-3xl">
          <Link href="/">
            <Button variant="ghost" size="sm" className="mb-6 text-muted-foreground">
              <ArrowLeft className="h-4 w-4 mr-1" /> {t("common.back")}
            </Button>
          </Link>

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            {/* Header */}
            <div className="text-center mb-10">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/8 text-primary text-sm font-medium mb-4">
                <Store className="h-4 w-4" />
                <span>{language === "sw" ? "Jiandikishe Mgahawa" : "Restaurant Registration"}</span>
              </div>
              <h1 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-3">
                {language === "sw" ? "Jiunge na NjamasiEats" : "Join NjamasiEats"}
              </h1>
              <p className="text-muted-foreground max-w-xl mx-auto">
                {language === "sw"
                  ? "Jaza fomu hii ili kuandikisha mgahawa wako kwenye NjamasiEats. Tutakuchunguza na kukujulisha hivi karibuni."
                  : "Fill out this form to register your restaurant on NjamasiEats. We will review and notify you shortly."}
              </p>
            </div>

            <Card className="border-border/50 shadow-sm">
              <CardContent className="p-6 md:p-8">
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Owner Information Section */}
                  <div>
                    <h2 className="font-display text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
                      <Users className="h-5 w-5 text-primary" />
                      {language === "sw" ? "Taarifa za Mmiliki" : "Owner Information"}
                    </h2>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="ownerName">
                          {language === "sw" ? "Jina Kamili la Mmiliki" : "Owner Full Name"} *
                        </Label>
                        <Input
                          id="ownerName"
                          value={form.ownerName}
                          onChange={e => updateForm("ownerName", e.target.value)}
                          placeholder={language === "sw" ? "Jina lako kamili" : "Your full name"}
                          className="h-11"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="ownerEmail">
                          {language === "sw" ? "Barua Pepe" : "Email Address"} *
                        </Label>
                        <div className="relative">
                          <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                          <Input
                            id="ownerEmail"
                            type="email"
                            value={form.ownerEmail}
                            onChange={e => updateForm("ownerEmail", e.target.value)}
                            placeholder="you@email.com"
                            className="h-11 pl-10"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="ownerPhone">
                          {language === "sw" ? "Nambari ya Simu" : "Phone Number"} *
                        </Label>
                        <div className="relative">
                          <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                          <Input
                            id="ownerPhone"
                            value={form.ownerPhone}
                            onChange={e => updateForm("ownerPhone", e.target.value)}
                            placeholder="+255 7XX XXX XXX"
                            className="h-11 pl-10"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Restaurant Information Section */}
                  <div>
                    <h2 className="font-display text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
                      <Utensils className="h-5 w-5 text-primary" />
                      {language === "sw" ? "Taarifa za Mgahawa" : "Restaurant Information"}
                    </h2>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="restaurantName">
                          {language === "sw" ? "Jina la Mgahawa" : "Restaurant Name"} *
                        </Label>
                        <Input
                          id="restaurantName"
                          value={form.restaurantName}
                          onChange={e => updateForm("restaurantName", e.target.value)}
                          placeholder={language === "sw" ? "Jina la mgahawa wako" : "Your restaurant name"}
                          className="h-11"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="cuisineType">
                          {language === "sw" ? "Aina ya Chakula" : "Cuisine Type"}
                        </Label>
                        <Input
                          id="cuisineType"
                          value={form.cuisineType}
                          onChange={e => updateForm("cuisineType", e.target.value)}
                          placeholder={language === "sw" ? "Mfano: Wali, Pizza, Kuku" : "e.g. Rice, Pizza, Chicken"}
                          className="h-11"
                        />
                      </div>

                      <div className="space-y-2 md:col-span-2">
                        <Label htmlFor="restaurantAddress">
                          {language === "sw" ? "Anwani ya Mgahawa" : "Restaurant Address"} *
                        </Label>
                        <div className="relative">
                          <MapPin className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                          <Textarea
                            id="restaurantAddress"
                            value={form.restaurantAddress}
                            onChange={e => updateForm("restaurantAddress", e.target.value)}
                            placeholder={language === "sw" ? "Anwani kamili ya mgahawa wako" : "Full address of your restaurant"}
                            className="min-h-[80px] pl-10"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="restaurantPhone">
                          {language === "sw" ? "Simu ya Mgahawa" : "Restaurant Phone"}
                        </Label>
                        <Input
                          id="restaurantPhone"
                          value={form.restaurantPhone}
                          onChange={e => updateForm("restaurantPhone", e.target.value)}
                          placeholder="+255 7XX XXX XXX"
                          className="h-11"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="deliveryMethod">
                          {language === "sw" ? "Njia ya Usafirishaji" : "Delivery Method"}
                        </Label>
                        <Select
                          value={form.deliveryMethod}
                          onValueChange={v => updateForm("deliveryMethod", v)}
                        >
                          <SelectTrigger className="h-11">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="self_pickup">
                              {language === "sw" ? "Kuchukua Mwenyewe" : "Self-Pickup"}
                            </SelectItem>
                            <SelectItem value="restaurant_delivery">
                              {language === "sw" ? "Usafirishaji wa Mgahawa" : "Restaurant Delivery"}
                            </SelectItem>
                            <SelectItem value="independent_rider">
                              {language === "sw" ? "Mudaumini" : "Independent Rider"}
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2 md:col-span-2">
                        <Label htmlFor="restaurantDescription">
                          {language === "sw" ? "Maelezo ya Mgahawa" : "Restaurant Description"}
                        </Label>
                        <Textarea
                          id="restaurantDescription"
                          value={form.restaurantDescription}
                          onChange={e => updateForm("restaurantDescription", e.target.value)}
                          placeholder={language === "sw"
                            ? "Eleza kuhusu mgahawa wako: chakula unachotoa, historia yako, n.k."
                            : "Describe your restaurant: what you serve, your story, etc."}
                          className="min-h-[100px]"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Login Prompt */}
                  {!isAuthenticated && (
                    <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3">
                      <div className="shrink-0 w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center">
                        <Mail className="h-4 w-4 text-amber-700" />
                      </div>
                      <div>
                        <p className="text-sm text-amber-800 font-medium">
                          {language === "sw" ? "Tafadhali ingia kwanza" : "Please sign in first"}
                        </p>
                        <p className="text-xs text-amber-600 mt-1">
                          {language === "sw"
                            ? "Kuwa na akaunti kunatusaidia kufuata maombi yako. Si lazima kuingia."
                            : "Having an account helps us track your application. Sign in is optional."}
                        </p>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          className="mt-2 bg-white"
                          onClick={() => startLogin()}
                        >
                          {t("nav.login")}
                        </Button>
                      </div>
                    </div>
                  )}

                  {/* Submit Button */}
                  <div className="pt-2">
                    <Button
                      type="submit"
                      size="lg"
                      className="w-full gap-2 shadow-lg shadow-primary/20"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? (
                        <>
                          <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                          {language === "sw" ? "Inatuma..." : "Submitting..."}
                        </>
                      ) : (
                        <>
                          <Store className="h-4 w-4" />
                          {language === "sw" ? "Tuma Maombi" : "Submit Application"}
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </main>
    </div>
  );
}
