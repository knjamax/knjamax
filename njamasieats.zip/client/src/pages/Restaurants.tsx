import { useLanguage } from "@/contexts/LanguageContext";
import Navigation from "@/components/Navigation";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { MapPin, Star, Search, ArrowRight } from "lucide-react";
import { Link } from "wouter";
import { useMemo, useState } from "react";
import { motion } from "framer-motion";

export default function Restaurants() {
  const { t, language } = useLanguage();
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const { data: restaurants, isLoading } = trpc.restaurants.list.useQuery();
  const { data: categories } = trpc.categories.list.useQuery();

  // Filter restaurants by category: check if any menu item in the restaurant belongs to the selected category
  const filteredRestaurants = useMemo(() => {
    if (!restaurants) return [];
    return restaurants.filter(r => {
      const matchesSearch = !search || r.name.toLowerCase().includes(search.toLowerCase());
      // Category filter works by matching the category name against menu items (not address)
      // Since we don't have menu items here, we filter by the restaurant's general description matching
      // In practice, categories are used on the menu page. Here we just do a general search.
      const matchesCategory = !selectedCategory || 
        r.name.toLowerCase().includes(selectedCategory.toLowerCase()) ||
        r.description?.toLowerCase().includes(selectedCategory.toLowerCase());
      return matchesSearch && matchesCategory;
    });
  }, [restaurants, search, selectedCategory]);

  const formatTzs = (amount: number) => {
    return new Intl.NumberFormat("sw-TZ", { style: "currency", currency: "TZS", minimumFractionDigits: 0 }).format(amount);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />

      <main className="flex-1">
        {/* Header */}
        <section className="py-12 md:py-16 bg-gradient-to-b from-primary/5 to-background">
          <div className="container">
            <motion.h1
              className="font-display text-3xl md:text-4xl font-bold text-center mb-8 text-foreground"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
            >
              {t("restaurants.title")}
            </motion.h1>

            {/* Search */}
            <div className="max-w-xl mx-auto relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder={t("restaurants.search")}
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="pl-10 h-12 bg-white shadow-sm border-border/50"
              />
            </div>

            {/* Category Filter */}
            {categories && categories.length > 0 && (
              <div className="flex items-center justify-center gap-2 mt-6 flex-wrap">
                <Button
                  variant={selectedCategory === null ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(null)}
                >
                  {t("restaurants.allCategories")}
                </Button>
                {categories.map(cat => (
                  <Button
                    key={cat.id}
                    variant={selectedCategory === cat.nameEn ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedCategory(cat.nameEn)}
                  >
                    {language === "sw" && cat.nameSw ? cat.nameSw : cat.nameEn}
                  </Button>
                ))}
              </div>
            )}
          </div>
        </section>

        {/* Restaurant Grid */}
        <section className="py-10">
          <div className="container">
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="h-64 rounded-2xl bg-muted animate-pulse" />
                ))}
              </div>
            ) : filteredRestaurants.length === 0 ? (
              <div className="text-center py-20">
                <p className="text-muted-foreground text-lg">{t("restaurants.noResults")}</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredRestaurants.map((restaurant, i) => (
                  <motion.div
                    key={restaurant.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.05 }}
                  >
                    <Link href={`/restaurants/${restaurant.id}`}>
                      <Card className="group overflow-hidden border-border/50 hover:border-primary/20 hover:shadow-xl transition-all duration-300 cursor-pointer">
                        {/* Cover */}
                        <div className="relative h-40 bg-gradient-to-br from-primary/10 to-accent/10 overflow-hidden">
                          {restaurant.coverImageUrl ? (
                            <img src={restaurant.coverImageUrl} alt={restaurant.name} className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center">
                              <span className="font-display text-2xl font-bold text-primary/30">
                                {restaurant.name.charAt(0)}
                              </span>
                            </div>
                          )}
                          <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                          <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between">
                            <Badge
                              variant={restaurant.isOpen ? "default" : "secondary"}
                              className="text-xs"
                            >
                              {restaurant.isOpen ? t("restaurants.open") : t("restaurants.closed")}
                            </Badge>
                            <div className="flex items-center gap-1 text-white">
                              <Star className="h-3.5 w-3.5 fill-accent text-accent" />
                              <span className="text-xs font-semibold">{restaurant.rating}</span>
                            </div>
                          </div>
                        </div>

                        <CardContent className="p-4">
                          <h3 className="font-display text-lg font-semibold mb-1 text-foreground group-hover:text-primary transition-colors">
                            {restaurant.name}
                          </h3>
                          {restaurant.address && (
                            <div className="flex items-center gap-1 text-sm text-muted-foreground mb-2">
                              <MapPin className="h-3.5 w-3.5" />
                              <span className="truncate">{restaurant.address}</span>
                            </div>
                          )}
                          <div className="flex items-center justify-between mt-3">
                            <span className="text-xs text-muted-foreground">
                              {t("restaurants.delivery")}: {formatTzs(restaurant.deliveryFee)}
                            </span>
                            <span className="text-xs font-medium text-primary flex items-center gap-1">
                              {t("restaurants.viewMenu")} <ArrowRight className="h-3 w-3" />
                            </span>
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </section>

        {/* Footer */}
        <footer className="py-8 bg-white border-t border-border/50 mt-auto">
          <div className="container text-center">
            <p className="text-xs text-muted-foreground">{t("common.ownedBy")} — Singida, Tanzania</p>
          </div>
        </footer>
      </main>
    </div>
  );
}
