import { useLanguage } from "@/contexts/LanguageContext";
import Navigation from "@/components/Navigation";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { ArrowLeft, CheckCircle2, Circle, Clock, Package, Truck, Bike, MapPin } from "lucide-react";
import { Link, useRoute } from "wouter";
import { useMemo } from "react";
import { motion } from "framer-motion";

type OrderStatus = "pending" | "confirmed" | "preparing" | "ready" | "picked_up" | "delivering" | "delivered" | "cancelled";

const statusOrder: OrderStatus[] = ["pending", "confirmed", "preparing", "ready", "picked_up", "delivering", "delivered"];

const statusLabels: Record<string, { en: string; sw: string }> = {
  pending: { en: "Pending", sw: "Inasubiri" },
  confirmed: { en: "Confirmed", sw: "Imethibitishwa" },
  preparing: { en: "Preparing", sw: "Inatayarishwa" },
  ready: { en: "Ready", sw: "Imeandaliwa" },
  picked_up: { en: "Picked Up", sw: "Imechukuliwa" },
  delivering: { en: "Delivering", sw: "Inasafirishwa" },
  delivered: { en: "Delivered", sw: "Imefika" },
  cancelled: { en: "Cancelled", sw: "Imeghairiwa" },
};

const deliveryMethodLabels: Record<string, { en: string; sw: string }> = {
  self_pickup: { en: "Self-Pickup", sw: "Kuchukua Mwenyewe" },
  restaurant_delivery: { en: "Restaurant Delivery", sw: "Usafirishaji wa Mgahawa" },
  independent_rider: { en: "Independent Rider", sw: "Mudaumini" },
};

const paymentMethodLabels: Record<string, { en: string; sw: string }> = {
  mpesa: { en: "M-Pesa", sw: "M-Pesa" },
  airtel_money: { en: "Airtel Money", sw: "Airtel Money" },
  cash_on_delivery: { en: "Cash on Delivery", sw: "Pesa Taslimu" },
};

export default function OrderTracking() {
  const { t, language } = useLanguage();
  const [, params] = useRoute("/orders/:id");
  const orderId = parseInt(params?.id || "0");

  const { data: order, isLoading } = trpc.orders.getById.useQuery({ id: orderId }, {
    refetchInterval: 5000, // Poll every 5 seconds for live updates
  });

  const formatTzs = (amount: number) =>
    new Intl.NumberFormat("sw-TZ", { style: "currency", currency: "TZS", minimumFractionDigits: 0 }).format(amount);

  const currentStatusIndex = useMemo(() => {
    if (!order) return -1;
    const idx = statusOrder.indexOf(order.status as OrderStatus);
    return idx;
  }, [order]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navigation />
        <div className="flex-1 flex items-center justify-center">
          <p className="text-muted-foreground">{t("common.loading")}</p>
        </div>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navigation />
        <div className="flex-1 flex items-center justify-center">
          <p className="text-muted-foreground">{t("common.error")}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />

      <main className="flex-1 py-8">
        <div className="container max-w-2xl">
          <Link href="/orders">
            <Button variant="ghost" size="sm" className="mb-6 text-muted-foreground">
              <ArrowLeft className="h-4 w-4 mr-1" /> {t("common.back")}
            </Button>
          </Link>

          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="font-display text-3xl font-bold text-foreground">
                {t("tracking.title")}
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                #{order.id} — {new Date(order.createdAt).toLocaleString()}
              </p>
            </div>
            <Badge
              variant={order.status === "delivered" ? "default" : order.status === "cancelled" ? "destructive" : "secondary"}
              className="text-sm px-3 py-1"
            >
              {statusLabels[order.status]?.[language] || order.status}
            </Badge>
          </div>

          {/* Status Timeline */}
          {order.status !== "cancelled" && (
            <Card className="mb-6 border-border/50">
              <CardContent className="p-6">
                <div className="relative">
                  {statusOrder.map((status, i) => {
                    const isActive = i <= currentStatusIndex;
                    const isCurrent = i === currentStatusIndex;
                    return (
                      <motion.div
                        key={status}
                        className="flex items-start gap-4 mb-6 last:mb-0"
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: isActive ? 1 : 0.3, x: 0 }}
                        transition={{ delay: i * 0.05 }}
                      >
                        <div className="flex flex-col items-center">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0
                            ${isCurrent ? "bg-primary text-white shadow-lg shadow-primary/30" : isActive ? "bg-success text-white" : "bg-muted"}`}>
                            {isActive && !isCurrent ? <CheckCircle2 className="h-4 w-4" /> : isCurrent ? <Clock className="h-4 w-4" /> : <Circle className="h-3 w-3" />}
                          </div>
                          {i < statusOrder.length - 1 && (
                            <div className={`w-0.5 h-8 mt-1 ${isActive ? "bg-success" : "bg-muted"}`} />
                          )}
                        </div>
                        <div className="pt-1">
                          <p className={`text-sm font-medium ${isCurrent ? "text-primary" : isActive ? "text-foreground" : "text-muted-foreground"}`}>
                            {statusLabels[status]?.[language] || status}
                          </p>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Order Details */}
          <Card className="mb-6 border-border/50">
            <CardContent className="p-6">
              <h2 className="font-display text-lg font-semibold mb-4">{t("tracking.items")}</h2>
              <div className="space-y-2">
                {order.items?.map(item => (
                  <div key={item.id} className="flex justify-between items-center py-2 border-b border-border/50 last:border-0">
                    <div>
                      <span className="text-sm font-medium">
                        {language === "sw" ? item.itemNameSw : item.itemNameEn}
                      </span>
                      <span className="text-xs text-muted-foreground ml-2">x{item.quantity}</span>
                    </div>
                    <span className="text-sm font-semibold">{formatTzs(item.totalPrice)}</span>
                  </div>
                ))}
              </div>
              <Separator className="my-4" />
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">{t("cart.deliveryFee")}</span>
                  <span>{formatTzs(order.deliveryFee)}</span>
                </div>
                <div className="flex justify-between text-lg font-bold pt-2">
                  <span>{t("cart.total")}</span>
                  <span className="text-primary">{formatTzs(order.totalAmount)}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Info Cards */}
          <div className="grid grid-cols-2 gap-4">
            <Card className="border-border/50">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                  {order.deliveryMethod === "self_pickup" ? <MapPin className="h-4 w-4" /> :
                   order.deliveryMethod === "restaurant_delivery" ? <Truck className="h-4 w-4" /> : <Bike className="h-4 w-4" />}
                  {t("tracking.deliveryMethod")}
                </div>
                <p className="font-medium text-sm">
                  {deliveryMethodLabels[order.deliveryMethod]?.[language] || order.deliveryMethod}
                </p>
              </CardContent>
            </Card>
            <Card className="border-border/50">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                  <Package className="h-4 w-4" />
                  {t("tracking.paymentMethod")}
                </div>
                <p className="font-medium text-sm">
                  {paymentMethodLabels[order.paymentMethod]?.[language] || order.paymentMethod}
                </p>
                <Badge variant={order.paymentStatus === "paid" ? "default" : "secondary"} className="mt-1 text-xs">
                  {order.paymentStatus}
                </Badge>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
