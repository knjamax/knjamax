import { useLanguage } from "@/contexts/LanguageContext";
import { useCart } from "@/contexts/CartContext";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { Button } from "@/components/ui/button";
import { ShoppingCart, Globe, Menu, X, User, LayoutDashboard, Store } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function Navigation() {
  const { t, language, setLanguage } = useLanguage();
  const { getItemCount } = useCart();
  const { user, loading, isAuthenticated, logout } = useAuth();
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  const isAdmin = user?.role === "admin";
  const itemCount = getItemCount();

  const navLinks = [
    { path: "/", label: t("nav.home") },
    { path: "/restaurants", label: t("nav.restaurants") },
    { path: "/cart", label: t("nav.cart"), showBadge: true },
  ];

  if (isAuthenticated) {
    navLinks.push({ path: "/orders", label: t("nav.orders") });
  }

  // Partner With Us link - visible to all users
  const partnerLink = { path: "/register-restaurant", label: language === "sw" ? "Jiunge Nasi" : "Partner With Us" };

  return (
    <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-xl border-b border-border/50">
      <div className="container flex items-center justify-between h-16">
        {/* Logo */}
        <Link href="/">
          <div className="flex items-center gap-2.5 cursor-pointer">
            <img
              src="/manus-storage/knjamasi_logo_974e872d.png"
              alt="K.NJAMASI"
              className="h-9 w-9 rounded-full object-cover"
            />
            <span className="font-display text-xl font-bold tracking-tight text-foreground">
              Njamasi<span className="text-accent">Eats</span>
            </span>
          </div>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-1">
          {navLinks.map(link => (
            <Link key={link.path} href={link.path}>
              <span className={`relative flex items-center gap-1.5 px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200
                ${location === link.path
                  ? "text-primary bg-primary/8"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted"
                }`}>
                {link.label}
                {link.showBadge && itemCount > 0 && (
                  <span className="flex items-center justify-center h-5 min-w-[1.25rem] px-1.5 text-[10px] font-bold bg-accent text-accent-foreground rounded-full">
                    {itemCount}
                  </span>
                )}
              </span>
            </Link>
          ))}
          {isAdmin && (
            <Link href="/dashboard">
              <span className={`flex items-center gap-1.5 px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200
                ${location === "/dashboard"
                  ? "text-primary bg-primary/8"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted"
                }`}>
                <LayoutDashboard className="h-4 w-4" />
                {t("nav.dashboard")}
              </span>
            </Link>
          )}
          <Link href="/register-restaurant">
            <span className={`flex items-center gap-1.5 px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200
              ${location === "/register-restaurant"
                ? "text-accent bg-accent/8"
                : "text-accent hover:text-accent/80 hover:bg-accent/5"
              }`}>
              <Store className="h-4 w-4" />
              {partnerLink.label}
            </span>
          </Link>
        </nav>

        {/* Right Actions */}
        <div className="hidden md:flex items-center gap-2">
          {/* Language Toggle */}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLanguage(language === "en" ? "sw" : "en")}
            className="flex items-center gap-1.5 text-muted-foreground"
          >
            <Globe className="h-4 w-4" />
            <span className="text-xs font-semibold uppercase">{language}</span>
          </Button>

          {/* Auth */}
          {loading ? null : isAuthenticated ? (
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">{user?.name || "User"}</span>
              <Button variant="ghost" size="sm" onClick={logout}>
                {t("nav.logout")}
              </Button>
            </div>
          ) : (
            <Button size="sm" onClick={() => startLogin()} className="gap-1.5">
              <User className="h-4 w-4" />
              {t("nav.login")}
            </Button>
          )}
        </div>

        {/* Mobile Menu Button */}
        <div className="flex md:hidden items-center gap-2">
          <Button variant="ghost" size="icon" onClick={() => setMobileOpen(!mobileOpen)}>
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            className="md:hidden border-t border-border/50 bg-white/95 backdrop-blur-xl"
          >
            <div className="container py-3 space-y-1">
              {navLinks.map(link => (
                <Link key={link.path} href={link.path} onClick={() => setMobileOpen(false)}>
                  <span className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium
                    ${location === link.path ? "text-primary bg-primary/8" : "text-muted-foreground"}`}>
                    {link.label}
                    {link.showBadge && itemCount > 0 && (
                      <span className="flex items-center justify-center h-5 min-w-[1.25rem] px-1.5 text-[10px] font-bold bg-accent text-accent-foreground rounded-full">
                        {itemCount}
                      </span>
                    )}
                  </span>
                </Link>
              ))}
              {isAdmin && (
                <Link href="/dashboard" onClick={() => setMobileOpen(false)}>
                  <span className="flex items-center gap-1.5 px-3 py-2.5 rounded-lg text-sm font-medium text-muted-foreground">
                    <LayoutDashboard className="h-4 w-4" />
                    {t("nav.dashboard")}
                  </span>
                </Link>
              )}
              <Link href="/register-restaurant" onClick={() => setMobileOpen(false)}>
                <span className="flex items-center gap-1.5 px-3 py-2.5 rounded-lg text-sm font-medium text-accent">
                  <Store className="h-4 w-4" />
                  {partnerLink.label}
                </span>
              </Link>
              <div className="flex items-center gap-2 px-3 pt-2 border-t border-border/50">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => { setLanguage(language === "en" ? "sw" : "en"); }}
                  className="gap-1.5"
                >
                  <Globe className="h-4 w-4" />
                  <span className="text-xs font-semibold uppercase">{language}</span>
                </Button>
                {!isAuthenticated && (
                  <Button size="sm" onClick={() => { startLogin(); setMobileOpen(false); }}>
                    {t("nav.login")}
                  </Button>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
