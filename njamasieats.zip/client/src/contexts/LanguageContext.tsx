import { createContext, useContext, useState, useCallback, type ReactNode } from "react";

type Language = "en" | "sw";

interface Translations {
  [key: string]: { en: string; sw: string };
}

const translations: Translations = {
  // Navigation
  "nav.home": { en: "Home", sw: "Nyumbani" },
  "nav.restaurants": { en: "Restaurants", sw: "Migahawa" },
  "nav.cart": { en: "Cart", sw: "Kikapu" },
  "nav.orders": { en: "My Orders", sw: "Maagizo Yangu" },
  "nav.dashboard": { en: "Dashboard", sw: "Dashibodi" },
  "nav.login": { en: "Sign In", sw: "Ingia" },
  "nav.logout": { en: "Sign Out", sw: "Ondoka" },

  // Landing
  "landing.title": { en: "Delicious Food, Delivered Fast", sw: "Chakula Tamu, Kinapelekwa Haraka" },
  "landing.subtitle": { en: "Order from your favorite restaurants and enjoy fresh meals delivered to your doorstep", sw: "Agiza kutoka kwenye migahawa yako unayopenda na ufurahie chakula kipya kinachokuletekea" },
  "landing.cta": { en: "Order Now", sw: "Agiza Sasa" },
  "landing.browse": { en: "Browse Restaurants", sw: "Angalia Migahawa" },
  "landing.howItWorks": { en: "How It Works", sw: "Inafanyaje Kazi" },
  "landing.step1Title": { en: "Choose a Restaurant", sw: "Chagua Mgahawa" },
  "landing.step1Desc": { en: "Browse our selection of top restaurants in your area", sw: "Angalia uchaguzi wetu wa migahawa bora katika eneo lako" },
  "landing.step2Title": { en: "Build Your Order", sw: "Tengeneza Agizo Lako" },
  "landing.step2Desc": { en: "Add your favorite dishes to the cart with ease", sw: "Ongeza vyakula vyako vipendwa kwenye kikapu kwa urahisi" },
  "landing.step3Title": { en: "Choose Delivery", sw: "Chagua Usafirishaji" },
  "landing.step3Desc": { en: "Self-pickup, restaurant delivery, or independent rider", sw: "Kuchukua mwenyewe, usafirishaji wa mgahawa, au mudaumini" },
  "landing.step4Title": { en: "Pay & Enjoy", sw: "Lipa na Furahia" },
  "landing.step4Desc": { en: "Pay via M-Pesa, Airtel Money, or cash on delivery", sw: "Lipa kupitia M-Pesa, Airtel Money, au pesa taslimu" },

  // Restaurants
  "restaurants.title": { en: "Our Restaurants", sw: "Migahawa Yetu" },
  "restaurants.search": { en: "Search restaurants...", sw: "Tafuta migahawa..." },
  "restaurants.allCategories": { en: "All", sw: "Zote" },
  "restaurants.delivery": { en: "Delivery", sw: "Usafirishaji" },
  "restaurants.open": { en: "Open", sw: "Wazi" },
  "restaurants.closed": { en: "Closed", sw: "Imefungwa" },
  "restaurants.viewMenu": { en: "View Menu", sw: "Ona Menyu" },
  "restaurants.noResults": { en: "No restaurants found", sw: "Hakuna migahawa iliyopatikana" },

  // Menu
  "menu.addToCart": { en: "Add to Cart", sw: "Ongeza Kwenye Kikapu" },
  "menu.available": { en: "Available", sw: "Inapatikana" },
  "menu.unavailable": { en: "Unavailable", sw: "Haipatikani" },
  "menu.quantity": { en: "Quantity", sw: "Idadi" },

  // Cart
  "cart.title": { en: "Your Cart", sw: "Kikapu Chako" },
  "cart.empty": { en: "Your cart is empty", sw: "Kikapu chako ni tupu" },
  "cart.browseRestaurants": { en: "Browse Restaurants", sw: "Angalia Migahawa" },
  "cart.subtotal": { en: "Subtotal", sw: "Jumla Ndogo" },
  "cart.deliveryFee": { en: "Delivery Fee", sw: "Ada ya Usafirishaji" },
  "cart.total": { en: "Total", sw: "Jumla" },
  "cart.checkout": { en: "Proceed to Checkout", sw: "Endelea Kulipa" },
  "cart.clearCart": { en: "Clear Cart", sw: "Futa Kikapu" },

  // Checkout
  "checkout.title": { en: "Checkout", sw: "Malipo" },
  "checkout.customerInfo": { en: "Customer Information", sw: "Taarifa za Mteja" },
  "checkout.name": { en: "Full Name", sw: "Jina Kamili" },
  "checkout.phone": { en: "Phone Number", sw: "Nambari ya Simu" },
  "checkout.address": { en: "Delivery Address", sw: "Anwani ya Usafirishaji" },
  "checkout.notes": { en: "Order Notes", sw: "Maelezo ya Agizo" },
  "checkout.deliveryMethod": { en: "Delivery Method", sw: "Njia ya Usafirishaji" },
  "checkout.selfPickup": { en: "Self-Pickup", sw: "Kuchukua Mwenyewe" },
  "checkout.restaurantDelivery": { en: "Restaurant Delivery", sw: "Usafirishaji wa Mgahawa" },
  "checkout.independentRider": { en: "Independent Rider", sw: "Mudaumini" },
  "checkout.paymentMethod": { en: "Payment Method", sw: "Njia ya Malipo" },
  "checkout.mpesa": { en: "M-Pesa", sw: "M-Pesa" },
  "checkout.airtelMoney": { en: "Airtel Money", sw: "Airtel Money" },
  "checkout.cashOnDelivery": { en: "Cash on Delivery", sw: "Pesa Taslimu" },
  "checkout.placeOrder": { en: "Place Order", sw: "Weka Agizo" },
  "checkout.orderPlaced": { en: "Order Placed Successfully!", sw: "Agizo Limewekwa Kwa Mafanikio!" },
  "checkout.orderSuccess": { en: "Your order has been placed and will be prepared shortly.", sw: "Agizo lako limewekwa na litatayarishwa hivi karibuni." },
  "checkout.trackOrder": { en: "Track Order", sw: "Fuatilia Agizo" },

  // Order Tracking
  "tracking.title": { en: "Track Your Order", sw: "Fuatilia Agizo Lako" },
  "tracking.status": { en: "Status", sw: "Hali" },
  "tracking.pending": { en: "Pending", sw: "Inasubiri" },
  "tracking.confirmed": { en: "Confirmed", sw: "Imethibitishwa" },
  "tracking.preparing": { en: "Preparing", sw: "Inatayarishwa" },
  "tracking.ready": { en: "Ready", sw: "Imeandaliwa" },
  "tracking.pickedUp": { en: "Picked Up", sw: "Imechukuliwa" },
  "tracking.delivering": { en: "Delivering", sw: "Inasafirishwa" },
  "tracking.delivered": { en: "Delivered", sw: "Imefika" },
  "tracking.cancelled": { en: "Cancelled", sw: "Imeghairiwa" },
  "tracking.orderNumber": { en: "Order", sw: "Agizo" },
  "tracking.items": { en: "Items", sw: "Bidhaa" },
  "tracking.deliveryMethod": { en: "Delivery", sw: "Usafirishaji" },
  "tracking.paymentMethod": { en: "Payment", sw: "Malipo" },
  "tracking.date": { en: "Date", sw: "Tarehe" },

  // Dashboard
  "dashboard.title": { en: "Owner Dashboard", sw: "Dashibodi ya Mmiliki" },
  "dashboard.overview": { en: "Overview", sw: "Muhtasari" },
  "dashboard.restaurants": { en: "Restaurants", sw: "Migahawa" },
  "dashboard.menuItems": { en: "Menu Items", sw: "Bidhaa za Menyu" },
  "dashboard.orders": { en: "Orders", sw: "Maagizo" },
  "dashboard.addRestaurant": { en: "Add Restaurant", sw: "Ongeza Mgahawa" },
  "dashboard.addMenuItem": { en: "Add Menu Item", sw: "Ongeza Bidhaa ya Menyu" },
  "dashboard.editRestaurant": { en: "Edit Restaurant", sw: "Hariri Mgahawa" },
  "dashboard.editMenuItem": { en: "Edit Menu Item", sw: "Hariri Bidhaa ya Menyu" },
  "dashboard.delete": { en: "Delete", sw: "Futa" },
  "dashboard.edit": { en: "Edit", sw: "Hariri" },
  "dashboard.name": { en: "Name", sw: "Jina" },
  "dashboard.address": { en: "Address", sw: "Anwani" },
  "dashboard.phone": { en: "Phone", sw: "Simu" },
  "dashboard.status": { en: "Status", sw: "Hali" },
  "dashboard.deliveryFee": { en: "Delivery Fee", sw: "Ada ya Usafirishaji" },
  "dashboard.price": { en: "Price (TZS)", sw: "Bei (TZS)" },
  "dashboard.category": { en: "Category", sw: "Kategoria" },
  "dashboard.available": { en: "Available", sw: "Inapatikana" },
  "dashboard.actions": { en: "Actions", sw: "Vitendo" },
  "dashboard.save": { en: "Save", sw: "Hifadhi" },
  "dashboard.cancel": { en: "Cancel", sw: "Ghairi" },
  "dashboard.open": { en: "Open", sw: "Wazi" },
  "dashboard.closed": { en: "Closed", sw: "Imefungwa" },

  // Orders
  "orders.signInRequired": { en: "Please sign in to view your orders", sw: "Tafadhali ingia ili kuona maagizo yako" },
  "orders.noOrders": { en: "No orders yet", sw: "Hakuna maagizo bado" },
  "orders.items": { en: "items", sw: "bidhaa" },

  // Cart
  "cart.items": { en: "items", sw: "bidhaa" },

  // Common
  "common.loading": { en: "Loading...", sw: "Inapakia..." },
  "common.error": { en: "Something went wrong", sw: "Hitilafu imetokea" },
  "common.retry": { en: "Retry", sw: "Jaribu Tena" },
  "common.back": { en: "Back", sw: "Rudi" },
  "common.ownedBy": { en: "Powered by K.NJAMASI IT SMART TECH", sw: "Imetengenezwa na K.NJAMASI IT SMART TECH" },
  "common.featureComingSoon": { en: "Feature coming soon", sw: "Kipengele kinakuja hivi karibuni" },
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType>({
  language: "en",
  setLanguage: () => {},
  t: (key: string) => key,
});

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>(() => {
    const stored = localStorage.getItem("njamasieats-lang");
    return (stored === "sw" || stored === "en") ? stored : "en";
  });

  const handleSetLanguage = useCallback((lang: Language) => {
    setLanguage(lang);
    localStorage.setItem("njamasieats-lang", lang);
  }, []);

  const t = useCallback(
    (key: string) => {
      const entry = translations[key];
      return entry ? entry[language] : key;
    },
    [language]
  );

  return (
    <LanguageContext.Provider value={{ language, setLanguage: handleSetLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  return useContext(LanguageContext);
}
