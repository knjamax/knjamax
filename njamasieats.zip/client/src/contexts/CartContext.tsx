import { createContext, useContext, useState, useCallback, type ReactNode } from "react";
import { toast } from "sonner";

export interface CartItem {
  menuItemId: number;
  restaurantId: number;
  itemNameEn: string;
  itemNameSw: string;
  price: number;
  quantity: number;
}

interface CartContextType {
  items: CartItem[];
  addToCart: (item: Omit<CartItem, "quantity">) => void;
  removeFromCart: (menuItemId: number) => void;
  updateQuantity: (menuItemId: number, quantity: number) => void;
  clearCart: () => void;
  getSubtotal: () => number;
  getItemCount: () => number;
  restaurantId: number | null;
}

const CartContext = createContext<CartContextType>({
  items: [],
  addToCart: () => {},
  removeFromCart: () => {},
  updateQuantity: () => {},
  clearCart: () => {},
  getSubtotal: () => 0,
  getItemCount: () => 0,
  restaurantId: null,
});

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);

  const restaurantId = items.length > 0 ? items[0].restaurantId : null;

  const addToCart = useCallback((newItem: Omit<CartItem, "quantity">) => {
    setItems(prev => {
      const existing = prev.find(i => i.menuItemId === newItem.menuItemId);
      if (existing) {
        return prev.map(i =>
          i.menuItemId === newItem.menuItemId ? { ...i, quantity: i.quantity + 1 } : i
        );
      }
      // Check if adding to a different restaurant
      if (prev.length > 0 && prev[0].restaurantId !== newItem.restaurantId) {
        toast("Switch restaurants to add this item");
        return prev;
      }
      return [...prev, { ...newItem, quantity: 1 }];
    });
  }, []);

  const removeFromCart = useCallback((menuItemId: number) => {
    setItems(prev => prev.filter(i => i.menuItemId !== menuItemId));
  }, []);

  const updateQuantity = useCallback((menuItemId: number, quantity: number) => {
    if (quantity <= 0) {
      setItems(prev => prev.filter(i => i.menuItemId !== menuItemId));
      return;
    }
    setItems(prev =>
      prev.map(i => i.menuItemId === menuItemId ? { ...i, quantity } : i)
    );
  }, []);

  const clearCart = useCallback(() => {
    setItems([]);
  }, []);

  const getSubtotal = useCallback(() => {
    return items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  }, [items]);

  const getItemCount = useCallback(() => {
    return items.reduce((sum, item) => sum + item.quantity, 0);
  }, [items]);

  return (
    <CartContext.Provider value={{ items, addToCart, removeFromCart, updateQuantity, clearCart, getSubtotal, getItemCount, restaurantId }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  return useContext(CartContext);
}
