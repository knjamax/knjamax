import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import * as db from "./db";

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ─── Public: Categories ───────────────────────────────────
  categories: router({
    list: publicProcedure.query(async () => {
      return db.getAllCategories();
    }),
    create: protectedProcedure
      .input(z.object({ nameEn: z.string(), nameSw: z.string(), description: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
        await db.createCategory(input);
        return { success: true };
      }),
    update: protectedProcedure
      .input(z.object({ id: z.number(), nameEn: z.string(), nameSw: z.string(), description: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
        await db.updateCategory(input.id, { nameEn: input.nameEn, nameSw: input.nameSw, description: input.description });
        return { success: true };
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
        await db.deleteCategory(input.id);
        return { success: true };
      }),
  }),

  // ─── Public: Restaurants ──────────────────────────────────
  restaurants: router({
    list: publicProcedure.query(async () => {
      return db.getAllRestaurants();
    }),
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const restaurant = await db.getRestaurantById(input.id);
        if (!restaurant) throw new TRPCError({ code: 'NOT_FOUND' });
        return restaurant;
      }),
    create: protectedProcedure
      .input(z.object({
        name: z.string(),
        description: z.string().optional(),
        address: z.string().optional(),
        phone: z.string().optional(),
        logoUrl: z.string().optional(),
        coverImageUrl: z.string().optional(),
        isOpen: z.boolean().default(true),
        deliveryFee: z.number().default(0),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
        await db.createRestaurant(input);
        return { success: true };
      }),
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string(),
        description: z.string().optional(),
        address: z.string().optional(),
        phone: z.string().optional(),
        logoUrl: z.string().optional(),
        coverImageUrl: z.string().optional(),
        isOpen: z.boolean(),
        deliveryFee: z.number(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
        const { id, ...rest } = input;
        await db.updateRestaurant(id, rest);
        return { success: true };
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
        await db.deleteRestaurant(input.id);
        return { success: true };
      }),
  }),

  // ─── Public: Menu Items ───────────────────────────────────
  menuItems: router({
    getByRestaurant: publicProcedure
      .input(z.object({ restaurantId: z.number() }))
      .query(async ({ input }) => {
        return db.getMenuItemsByRestaurant(input.restaurantId);
      }),
    create: protectedProcedure
      .input(z.object({
        restaurantId: z.number(),
        nameEn: z.string(),
        nameSw: z.string(),
        description: z.string().optional(),
        descriptionSw: z.string().optional(),
        price: z.number(),
        category: z.string().optional(),
        imageUrl: z.string().optional(),
        isAvailable: z.boolean().default(true),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
        await db.createMenuItem(input);
        return { success: true };
      }),
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        nameEn: z.string(),
        nameSw: z.string(),
        description: z.string().optional(),
        descriptionSw: z.string().optional(),
        price: z.number(),
        category: z.string().optional(),
        imageUrl: z.string().optional(),
        isAvailable: z.boolean(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
        const { id, ...rest } = input;
        await db.updateMenuItem(id, rest);
        return { success: true };
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
        await db.deleteMenuItem(input.id);
        return { success: true };
      }),
  }),

  // ─── Orders ───────────────────────────────────────────────
  orders: router({
    create: protectedProcedure
      .input(z.object({
        restaurantId: z.number(),
        deliveryMethod: z.enum(["self_pickup", "restaurant_delivery", "independent_rider"]),
        paymentMethod: z.enum(["mpesa", "airtel_money", "cash_on_delivery"]),
        totalAmount: z.number(),
        deliveryFee: z.number().default(0),
        customerName: z.string(),
        customerPhone: z.string(),
        deliveryAddress: z.string().optional(),
        notes: z.string().optional(),
        items: z.array(z.object({
          menuItemId: z.number(),
          itemNameEn: z.string(),
          itemNameSw: z.string(),
          quantity: z.number(),
          unitPrice: z.number(),
          totalPrice: z.number(),
        })),
      }))
      .mutation(async ({ ctx, input }) => {
        const user = ctx.user;
        if (!user) throw new TRPCError({ code: 'UNAUTHORIZED' });

        const orderResult = await db.createOrder({
          userId: user.id,
          restaurantId: input.restaurantId,
          deliveryMethod: input.deliveryMethod,
          paymentMethod: input.paymentMethod,
          totalAmount: input.totalAmount,
          deliveryFee: input.deliveryFee,
          customerName: input.customerName,
          customerPhone: input.customerPhone,
          deliveryAddress: input.deliveryAddress || null,
          notes: input.notes || null,
          paymentStatus: input.paymentMethod === "cash_on_delivery" ? "paid" : "pending",
        });

        if (orderResult[0] && orderResult[0].insertId) {
          const orderId = orderResult[0].insertId;
          await db.createOrderItems(input.items.map(item => ({
            orderId,
            ...item,
          })));
        }

        return { success: true, orderId: orderResult[0]?.insertId || 0 };
      }),

    myOrders: protectedProcedure.query(async ({ ctx }) => {
      if (!ctx.user) throw new TRPCError({ code: 'UNAUTHORIZED' });
      const ordersList = await db.getOrdersByUser(ctx.user.id);
      const ordersWithItems = await Promise.all(
        ordersList.map(async (order) => {
          const items = await db.getOrderItemsByOrderId(order.id);
          const restaurant = await db.getRestaurantById(order.restaurantId);
          return { ...order, items, restaurant };
        })
      );
      return ordersWithItems;
    }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        const order = await db.getOrderById(input.id);
        if (!order) throw new TRPCError({ code: 'NOT_FOUND' });
        if (ctx.user?.role !== 'admin' && order.userId !== ctx.user?.id) {
          throw new TRPCError({ code: 'FORBIDDEN' });
        }
        const items = await db.getOrderItemsByOrderId(order.id);
        const restaurant = await db.getRestaurantById(order.restaurantId);
        return { ...order, items, restaurant };
      }),

    updateStatus: protectedProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(["pending", "confirmed", "preparing", "ready", "picked_up", "delivering", "delivered", "cancelled"]),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
        await db.updateOrderStatus(input.id, input.status);
        return { success: true };
      }),

    // Admin: all orders
    all: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user?.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
      const ordersList = await db.getAllOrders();
      const ordersWithItems = await Promise.all(
        ordersList.map(async (order) => {
          const items = await db.getOrderItemsByOrderId(order.id);
          const restaurant = await db.getRestaurantById(order.restaurantId);
          return { ...order, items, restaurant };
        })
      );
      return ordersWithItems;
    }),

    updatePaymentStatus: protectedProcedure
      .input(z.object({ id: z.number(), paymentStatus: z.enum(["pending", "paid", "failed"]) }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
        await db.updateOrderPaymentStatus(input.id, input.paymentStatus);
        return { success: true };
      }),
  }),

  // ─── Restaurant Owner Registration ───────────────────────
  ownerRegistration: router({
    // Public: Anyone can submit a registration
    register: publicProcedure
      .input(z.object({
        ownerName: z.string().min(2),
        ownerEmail: z.string().email(),
        ownerPhone: z.string().min(10),
        restaurantName: z.string().min(2),
        restaurantAddress: z.string().min(5),
        restaurantPhone: z.string().optional(),
        restaurantDescription: z.string().optional(),
        cuisineType: z.string().optional(),
        deliveryMethod: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const userId = ctx.user?.id || null;
        await db.createRestaurantOwner({
          ...input,
          userId,
          status: "pending",
          deliveryMethod: input.deliveryMethod || "self_pickup",
        });
        return { success: true };
      }),

    // Admin: View all registrations
    list: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user?.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
      return db.getAllRestaurantOwners();
    }),

    // Admin: Approve or reject
    updateStatus: protectedProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(["pending", "approved", "rejected"]),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
        await db.updateRestaurantOwnerStatus(input.id, input.status);
        return { success: true };
      }),

    // Public: Pending count for dashboard
    pendingCount: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user?.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
      return db.getPendingOwnerCount();
    }),
  }),
});

export type AppRouter = typeof appRouter;
