import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import { COOKIE_NAME } from "../shared/const";
import type { TrpcContext } from "./_core/context";

type CookieCall = {
  name: string;
  options: Record<string, unknown>;
};

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createMockDb() {
  return vi.hoisted(() => {
    const mockDb = {
      getAllCategories: vi.fn().mockResolvedValue([]),
      getAllRestaurants: vi.fn().mockResolvedValue([]),
      getRestaurantById: vi.fn().mockResolvedValue(null),
      createRestaurant: vi.fn().mockResolvedValue(undefined),
      updateRestaurant: vi.fn().mockResolvedValue(undefined),
      deleteRestaurant: vi.fn().mockResolvedValue(undefined),
      getMenuItemsByRestaurant: vi.fn().mockResolvedValue([]),
      createMenuItem: vi.fn().mockResolvedValue(undefined),
      updateMenuItem: vi.fn().mockResolvedValue(undefined),
      deleteMenuItem: vi.fn().mockResolvedValue(undefined),
      createOrder: vi.fn().mockResolvedValue([{ insertId: 1 }]),
      getOrderById: vi.fn().mockResolvedValue(null),
      getOrdersByUser: vi.fn().mockResolvedValue([]),
      getAllOrders: vi.fn().mockResolvedValue([]),
      getOrderItemsByOrderId: vi.fn().mockResolvedValue([]),
      createOrderItems: vi.fn().mockResolvedValue(undefined),
      updateOrderStatus: vi.fn().mockResolvedValue(undefined),
      updateOrderPaymentStatus: vi.fn().mockResolvedValue(undefined),
      upsertUser: vi.fn().mockResolvedValue(undefined),
      getUserByOpenId: vi.fn().mockResolvedValue(undefined),
    };
    return mockDb;
  });
}

function createAdminContext(): TrpcContext {
  const clearedCookies: CookieCall[] = [];
  const user: AuthenticatedUser = {
    id: 1,
    openId: "admin-user",
    email: "admin@example.com",
    name: "Admin User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {
      clearCookie: (name: string, options: Record<string, unknown>) => {
        clearedCookies.push({ name, options });
      },
    } as TrpcContext["res"],
  };
}

function createUserContext(): TrpcContext {
  const clearedCookies: CookieCall[] = [];
  const user: AuthenticatedUser = {
    id: 2,
    openId: "regular-user",
    email: "user@example.com",
    name: "Regular User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {
      clearCookie: (name: string, options: Record<string, unknown>) => {
        clearedCookies.push({ name, options });
      },
    } as TrpcContext["res"],
  };
}

describe("API Router", () => {
  describe("categories", () => {
    it("list returns empty array by default", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: { protocol: "https", headers: {} } as TrpcContext["req"],
        res: { clearCookie: vi.fn() } as TrpcContext["res"],
      });

      const result = await caller.categories.list();
      expect(Array.isArray(result)).toBe(true);
    });
  });

  describe("restaurants", () => {
    it("list returns empty array by default", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: { protocol: "https", headers: {} } as TrpcContext["req"],
        res: { clearCookie: vi.fn() } as TrpcContext["res"],
      });

      const result = await caller.restaurants.list();
      expect(Array.isArray(result)).toBe(true);
    });

    it("getById throws NOT_FOUND for non-existent restaurant", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: { protocol: "https", headers: {} } as TrpcContext["req"],
        res: { clearCookie: vi.fn() } as TrpcContext["res"],
      });

      await expect(caller.restaurants.getById({ id: 999 })).rejects.toThrow("NOT_FOUND");
    });

    it("create requires admin role", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);

      await expect(caller.restaurants.create({
        name: "Test Restaurant",
        isOpen: true,
        deliveryFee: 3000,
      })).rejects.toThrow("FORBIDDEN");
    });

    it("create succeeds for admin", async () => {
      const ctx = createAdminContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.restaurants.create({
        name: "Test Restaurant",
        isOpen: true,
        deliveryFee: 3000,
      });

      expect(result).toEqual({ success: true });
    });
  });

  describe("menuItems", () => {
    it("getByRestaurant returns empty array by default", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: { protocol: "https", headers: {} } as TrpcContext["req"],
        res: { clearCookie: vi.fn() } as TrpcContext["res"],
      });

      const result = await caller.menuItems.getByRestaurant({ restaurantId: 1 });
      expect(Array.isArray(result)).toBe(true);
    });

    it("create requires admin role", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);

      await expect(caller.menuItems.create({
        restaurantId: 1,
        nameEn: "Pizza",
        nameSw: "Piza",
        price: 5000,
      })).rejects.toThrow("FORBIDDEN");
    });
  });

  describe("orders", () => {
    it("create requires authentication", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: { protocol: "https", headers: {} } as TrpcContext["req"],
        res: { clearCookie: vi.fn() } as TrpcContext["res"],
      });

      await expect(caller.orders.create({
        restaurantId: 1,
        deliveryMethod: "self_pickup",
        paymentMethod: "cash_on_delivery",
        totalAmount: 10000,
        deliveryFee: 0,
        customerName: "Test User",
        customerPhone: "+255123456789",
        items: [{
          menuItemId: 1,
          itemNameEn: "Pizza",
          itemNameSw: "Piza",
          quantity: 2,
          unitPrice: 5000,
          totalPrice: 10000,
        }],
      })).rejects.toThrow();
    });

    it("updateStatus requires admin role", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);

      await expect(caller.orders.updateStatus({
        id: 1,
        status: "confirmed",
      })).rejects.toThrow("FORBIDDEN");
    });

    it("updateStatus succeeds for admin", async () => {
      const ctx = createAdminContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.orders.updateStatus({
        id: 1,
        status: "confirmed",
      });

      expect(result).toEqual({ success: true });
    });

    it("myOrders requires authentication", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: { protocol: "https", headers: {} } as TrpcContext["req"],
        res: { clearCookie: vi.fn() } as TrpcContext["res"],
      });

      await expect(caller.orders.myOrders()).rejects.toThrow();
    });
  });

  describe("auth", () => {
    it("me returns user info", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.auth.me();
      expect(result).not.toBeNull();
      expect(result?.email).toBe("user@example.com");
    });

    it("me returns null for unauthenticated", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: { protocol: "https", headers: {} } as TrpcContext["req"],
        res: { clearCookie: vi.fn() } as TrpcContext["res"],
      });

      const result = await caller.auth.me();
      expect(result).toBeNull();
    });
  });
});
